import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DialogoBuscadorComponent } from './dialogo-buscador.component';

describe('DialogoBuscadorComponent', () => {
  let component: DialogoBuscadorComponent;
  let fixture: ComponentFixture<DialogoBuscadorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DialogoBuscadorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DialogoBuscadorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
