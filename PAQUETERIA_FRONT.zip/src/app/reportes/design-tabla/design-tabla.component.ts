import { Component, OnInit } from '@angular/core';
import { NgbModal, ModalDismissReasons, NgbModalOptions} from '@ng-bootstrap/ng-bootstrap';
import { NgbCalendar, NgbDateStruct} from '@ng-bootstrap/ng-bootstrap';
import { Router} from '@angular/router';

@Component({
  selector: 'app-design-tabla',
  templateUrl: './design-tabla.component.html',
  styleUrls: ['./design-tabla.component.scss']
})
export class DesignTablaComponent implements OnInit {

  clientes=["BCP", "Interbank", "Scotiabank", "Continental", "Luz del Sur", "Movistar","Telefonica"]
  productos=["Estado de cuenta Visa", "Estado de cuenta Mastercard", "Estado de cuenta Diners", "Estado de cuenta Ahorros", "Cartas", "Recibo Agua","Recibo Luz"]
  couriers=["El Rápido", "El Lento", "Delivery ya", "Metrolima", "Globo", "Rappi", "Urbaner"]
  meses=["SET-2019", "AGO-2019", "JUL-2019", "JUN-2019", "MAY-2019", "ABR-2019", "MAR-2019"]
  years=["2019", "2018", "2017", "2016", "2015", "2014","2013"]

  submenulinks = false

  // VARIABLES DIALOGOS
  titulo = "Duplicar Registro"
  cuerpo = "Se generará un duplicado del registro"
  // success = 1 ; warning = 2 ; error = 3
  dialogoTipo = 1


  chartPeriodo = "d"
  clickchartPeriodo(p){
    this.chartPeriodo = p;
    // this.periodo.emit(this.chartPeriodo)
  }


  model: NgbDateStruct;
  model2: NgbDateStruct;


  constructor(private modalService: NgbModal,private calendar: NgbCalendar,private router: Router) { }

  controlOver = true
  clickControl(){
    this.controlOver = !this.controlOver
  }

  // controlOver = [false, false, false, false, false, false, false,]
  clickControlOver(n:number){
    var el = this.controlOver[n];
    el = !el
    // this.controlOver[n] = !this.controlOver[n]
  }


  // Selección múltiple
  selectall = false
  selectToggle(){
    this.selectall = !this.selectall
  }
  // FILTRO
  filtroHidden = true
  filtroToggle(){
    this.filtroHidden = !this.filtroHidden
  }


  /* POPUPS  */
  closeResult: string;
  modalOptionSmall: NgbModalOptions = {};
  modalOption: NgbModalOptions = {};

  openModalSmall(contenido) {
    this.modalOptionSmall.backdrop = 'static';
    this.modalOptionSmall.keyboard = false;
    this.modalService.open(contenido, this.modalOptionSmall).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  openModalLarge(contenido) {
    this.modalOption.backdrop = 'static';
    this.modalOption.keyboard = false;
    this.modalOption.windowClass = 'xlModal'
    this.modalService.open(contenido, this.modalOption).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  } open(content) {
    this.modalService.open(content);
  }

  /* FIN POPUPS  */

  ngOnInit() {
  }

}
