import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inconsistencia',
  templateUrl: './inconsistencia.component.html',
  styleUrls: ['./inconsistencia.component.scss']
})
export class InconsistenciaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  chartTipo = "bar" // bar, pie,line
  clickChangeTipo(ev) {
    this.chartTipo = ev;
    console.log(ev)
  }
  nivel = 1
  clickChangeNivel(n) {
    this.nivel = n
  }


  // FILTRO
  filtroHidden = true
  filtroToggle() {
    this.filtroHidden = !this.filtroHidden
  }

  activo: string = "B1"
  id_bar = [1, 2, 3]
  ids = [1, 2, 3, 4, 5, 6]

  mostrar() {
    var Opciones = (document.getElementById("tipo")) as HTMLSelectElement;
    var x = Opciones.value;
    this.activo = x;
  }
  // DATOS DEL CHART 1

  dataBar1 = {
    "id": 1,
    "titulo": "Inconsistencia",
    "cantidad-barras": 2,
    "leyenda": {
      "l1": "Lima",
      "l2": "Provincia"
    },
    "colores": {
      "color1": "#579AF1",
      "color2": "#8FBF55",
    },
    "data":
      [
        {
          "label": "Enero",
          "cantidad1": 350,
          "cantidad2": 100,
        },
        {
          "label": "Febrero",
          "cantidad1": 200,
          "cantidad2": 360,
        },
        {
          "label": "Marzo",
          "cantidad1": 600,
          "cantidad2": 400,
        },
      ]
  }

  dataBar2 = {
    "id": 2,
    "titulo": "Efectividad",
    "cantidad-barras": 4,
    "leyenda": {
      "l1": "Lima",
      "l2": "Provincia Urbana",
      "l3": "Provincia Rural",
      "l4": "Provincia Alejada"
    },
    "colores": {
      "color1": "#579AF1",
      "color2": "#8FBF55",
      "color3": "#333333",
      "color4": "#FAB445",
    },
    "data":
      [
        {
          "label": "Enero",
          "cantidad1": 350,
          "cantidad2": 60,
          "cantidad3": 25,
          "cantidad4": 15,
        },
        {
          "label": "Febrero",
          "cantidad1": 200,
          "cantidad2": 160,
          "cantidad3": 120,
          "cantidad4": 80,
        },
        {
          "label": "Marzo",
          "cantidad1": 600,
          "cantidad2": 80,
          "cantidad3": 120,
          "cantidad4": 200,
        },
      ]
  }

  dataPie = [
    {
      "titulo": "Enero",
      "data":
        [
          {
            "label": "Provincia",
            "color": "#579AF1",
            "cantidad": 350,
          },
          {
            "label": "Lima",
            "color": "#8FBF55",
            "cantidad": 100
          }
        ],
    },
    {
      "titulo": "Febrero",
      "data":
        [
          {
            "label": "Provincia",
            "color": "#579AF1",
            "cantidad": 200,
          },
          {
            "label": "Lima",
            "color": "#8FBF55",
            "cantidad": 360
          }
        ],
    },
    {
      "titulo": "Marzo",
      "data":
        [
          {
            "label": "Provincia",
            "color": "#579AF1",
            "cantidad": 600,
          },
          {
            "label": "Lima",
            "color": "#8FBF55",
            "cantidad": 400
          }
        ],
    }

  ]

  dataPie2 = [
    {
      "titulo": "Enero",
      "data":
        [
          {
            "label": "Lima",
            "color": "#579AF1",
            "cantidad": 350
          },
          {
            "label": "Provincia Urbana",
            "color": "#8FBF55",
            "cantidad": 60,
          },
          {
            "label": "Provincia Rural",
            "color": "#333333",
            "cantidad": 25,
          },
          {
            "label": "Provincia Alejada",
            "color": "#FAB445",
            "cantidad": 15
          }
        ],
    },
    {
      "titulo": "Febrero",
      "data":
        [
          {
            "label": "Lima",
            "color": "#579AF1",
            "cantidad": 200
          },
          {
            "label": "Provincia Urbana",
            "color": "#8FBF55",
            "cantidad": 160,
          },
          {
            "label": "Provincia Rural",
            "color": "#333333",
            "cantidad": 120,
          },
          {
            "label": "Provincia Alejada",
            "color": "#FAB445",
            "cantidad": 80
          }
        ],
    },
    {
      "titulo": "Marzo",
      "data":
        [
          {
            "label": "Lima",
            "color": "#579AF1",
            "cantidad": 600
          },
          {
            "label": "Provincia Urbana",
            "color": "#8FBF55",
            "cantidad": 80,
          },
          {
            "label": "Provincia Rural",
            "color": "#333333",
            "cantidad": 120,
          },
          {
            "label": "Provincia Alejada",
            "color": "#FAB445",
            "cantidad": 200
          }
        ],
    },
  ]
}
