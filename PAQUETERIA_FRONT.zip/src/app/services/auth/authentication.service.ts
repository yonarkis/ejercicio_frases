import { Injectable } from '@angular/core';
import { HttpClient,  HttpHeaders,  HttpParams} from '@angular/common/http';
import { Observable } from 'rxjs';

import { Session } from '../../models/auth/session.model';
import { Login } from '../../models/auth/login.model';
// import { Constant } from '../../utils/constant';

import { environment } from '../../../environments/environment';


@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  constructor(private http: HttpClient) {}

  private loginPath = environment.UrlServiceAPIOrders + "v1/auth/";


  login(loginObj: Login): Observable<Session> {
    let params = new HttpParams()
      .set('username', loginObj.usuario)
      .set('password', loginObj.contrasenia)
    let headers = new HttpHeaders().set(
      'Content-Type',
      'application/x-www-form-urlencoded'
    );

    return this.http.post<Session>(this.loginPath + 'login', params.toString(), {
      headers: headers
    });
  }

  
  login2(loginObj: any): Observable<any> {
    let params = new HttpParams()
      .set('username', loginObj.username)
      .set('password', loginObj.password)
    let headers = new HttpHeaders().set(
      'Content-Type',
      'application/x-www-form-urlencoded'
    );

    return this.http.post<any>(this.loginPath + 'login', params.toString(), {
      headers: headers
    });
  }

  // logout(): Observable<boolean> {
  //   return this.http.post<boolean>(Constant.baseURL + 'logout', {});
  // }

  // ObtenerCaptcha() {
  //   return this.http.get(Constant.baseURLSeguridad + 'user/captcha', {});
  // }
}
