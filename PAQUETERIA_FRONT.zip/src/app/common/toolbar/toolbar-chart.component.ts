import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import {NgbModal, ModalDismissReasons, NgbModalOptions} from '@ng-bootstrap/ng-bootstrap';
import {NgbCalendar, NgbDateStruct} from '@ng-bootstrap/ng-bootstrap';
import { Router} from '@angular/router';
// import { EventEmitter } from 'events';

@Component({
  selector: 'app-toolbar-chart',
  templateUrl: './toolbar-chart.component.html',
  styleUrls: ['./toolbar-chart.component.scss']
})
export class ToolbarChartComponent implements OnInit {

  @Output() tipo = new EventEmitter();
  @Output() nivel = new EventEmitter();
  @Output() periodo = new EventEmitter();
  @Input() nivelActual = 1
  

  clientes=["BCP", "Interbank", "Scotiabank", "Continental", "Luz del Sur", "Movistar","Telefonica"]
  productos=["Estado de cuenta Visa", "Estado de cuenta Mastercard", "Estado de cuenta Diners", "Estado de cuenta Ahorros", "Cartas", "Recibo Agua","Recibo Luz"]
  couriers=["El Rápido", "El Lento", "Delivery ya", "Metrolima", "Globo", "Rappi", "Urbaner"]
  meses=["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio"]
  years=["2019", "2018", "2017", "2016", "2015", "2014","2013"]


// CHARTS
  meta = false
  clickChangeMeta(){
    this.meta = !this.meta;
  }

  chartPeriodo = "d"
  clickchartPeriodo(p){
    this.chartPeriodo = p;
    this.periodo.emit(this.chartPeriodo)
  }

  chartTipo = "bar" // bar, pie, line
  clickChangeTipo(t){
    this.chartTipo = t;
    this.tipo.emit(this.chartTipo)
  }

  chartUnidad = "n" // n, p
  clickChangeUnidad(u){
    this.chartUnidad = u;
  }

  nivelLocal = 1
  clickChangeNivel(){
    this.nivel.emit(1)
  }

// FIN CHARTS


  submenulinks = false

  // VARIABLES DIALOGOS
  titulo = "Duplicar Registro"
  cuerpo = "Se generará un duplicado del registro"
  // success = 1 ; warning = 2 ; error = 3
  dialogoTipo = 1


  model: NgbDateStruct;
  model2: NgbDateStruct;


  constructor(private modalService: NgbModal,private calendar: NgbCalendar,private router: Router) { }

  controlOver = true
  clickControl(){
    this.controlOver = !this.controlOver
  }

  // controlOver = [false, false, false, false, false, false, false,]
  clickControlOver(n:number){
    var el = this.controlOver[n];
    el = !el
    // this.controlOver[n] = !this.controlOver[n]
  }


  // Selección múltiple
  selectall = false
  selectToggle(){
    this.selectall = !this.selectall
  }
  // FILTRO
  filtroHidden = true
  filtroToggle(){
    this.filtroHidden = !this.filtroHidden
  }


  /* POPUPS  */
  closeResult: string;
  modalOptionSmall: NgbModalOptions = {};
  modalOption: NgbModalOptions = {};

  openModalSmall(contenido) {
    this.modalOptionSmall.backdrop = 'static';
    this.modalOptionSmall.keyboard = false;
    this.modalService.open(contenido, this.modalOptionSmall).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  openModalLarge(contenido) {
    this.modalOption.backdrop = 'static';
    this.modalOption.keyboard = false;
    this.modalOption.windowClass = 'xlModal'
    this.modalService.open(contenido, this.modalOption).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  } open(content) {
    this.modalService.open(content);
  }

  /* FIN POPUPS  */

  ngOnInit() {
  }

}
