import { Component, OnInit, Input } from '@angular/core';
import { NgbModal, ModalDismissReasons, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-dialogo-relacionar',
  templateUrl: './dialogo-relacionar.component.html',
  styleUrls: ['./dialogo-relacionar.component.scss']
})
export class DialogoRelacionarComponent implements OnInit {

  // VARIABLES DIALOGOS
  @Input() titulo: string = "Duplicar Registro"
  @Input() cuerpo: string = "Se generará un duplicado del registro"
  // success = 1 ; warning = 2 ; error = 3
  @Input() dialogoTipo: number = 1

  selected = [false,false,false, false]
  clickItem(n){
    this.selected[n] = !this.selected[n]
  }

  constructor(public modalService: NgbModal) { }

  ngOnInit() {
  }

 /* POPUPS  */
 closeResult: string;
 modalOptionSmall: NgbModalOptions = {};
 modalOption: NgbModalOptions = {};

 openModalSmall(contenido) {
   this.modalOptionSmall.backdrop = 'static';
   this.modalOptionSmall.keyboard = false;
   this.modalService.open(contenido, this.modalOptionSmall).result.then((result) => {
     this.closeResult = `Closed with: ${result}`;
   }, (reason) => {
     this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
   });
 }

 openModalLarge(contenido) {
   this.modalOption.backdrop = 'static';
   this.modalOption.keyboard = false;
   this.modalOption.windowClass = 'xlModal'
   this.modalService.open(contenido, this.modalOption).result.then((result) => {
     this.closeResult = `Closed with: ${result}`;
   }, (reason) => {
     this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
   });
 }

 private getDismissReason(reason: any): string {
   if (reason === ModalDismissReasons.ESC) {
     return 'by pressing ESC';
   } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
     return 'by clicking on a backdrop';
   } else {
     return `with: ${reason}`;
   }
 } open(content) {
   this.modalService.open(content);
 }
}
