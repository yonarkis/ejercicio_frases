import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AtencionReclamosComponent } from './atencion-reclamos.component';

describe('AtencionReclamosComponent', () => {
  let component: AtencionReclamosComponent;
  let fixture: ComponentFixture<AtencionReclamosComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AtencionReclamosComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AtencionReclamosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
