import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { LoginComponent } from './common/login/login.component';

import { OriginComponent } from './common/origin/origin.component';
import { NavMainComponent } from './common/nav/nav-main.component';
import { DemoComponent } from './distrib/demo1/demo.component';

import { CreacionComponent } from './distrib/plantillas/creacion.component';
import { CrearNuevaComponent } from './distrib/plantillas/crear-nueva.component';
import { CrearDetalleComponent } from './distrib/plantillas/crear-detalle.component';
import { AsignacionComponent } from './distrib/plantillas/asignacion.component';
import { AsignarNuevaComponent } from './distrib/plantillas/asignar-nueva.component';
import { AsignarDetalleComponent } from './distrib/plantillas/asignar-detalle.component';

import { DialogoComponent } from './common/dialogo/dialogo.component';
import { DialogoVisibilidadComponent } from './common/dialogo/dialogo-visibilidad.component';
import { DialogoImportarExcelComponent } from './common/dialogo/dialogo-importar-excel.component';
import { DialogoEdicionTablaComponent } from './common/dialogo/dialogo-edicion-tabla.component';
import { DialogoRelacionarComponent } from './common/dialogo/dialogo-relacionar.component';
import { CourierComponent } from './courier/courier.component';
import { CourierAvanceComponent } from './courier/avance/courier-avance.component';
import { CourierCargaComponent } from './courier/courier-carga.component';
import { CourierDetalleComponent } from './courier/courier-detalle.component';
import { CourierLogComponent } from './courier/avance/courier-log.component';
import { CourierAvanceDetalleComponent } from './courier/avance/courier-avance-detalle.component';
import { CourierLogDetalleComponent } from './courier/avance/courier-log-detalle.component';
import { EficienciaComponent } from './distrib/dashboard/eficiencia/eficiencia.component';
import { EfectividadComponent } from './distrib/dashboard/efectividad/efectividad.component';
import { InconsistenciaComponent } from './distrib/dashboard/inconsistencia/inconsistencia.component';
import { ToolbarChartComponent } from './common/toolbar/toolbar-chart.component';
import { BarChartComponent } from './common/charts/bar-chart.component';
import { LineChartComponent } from './common/charts/line-chart.component';
import { PieChartComponent } from './common/charts/pie-chart.component';
// import { BuscadorComponent } from './common/toolbar/dialogos/buscador.component';
import { DialogoBuscadorComponent } from './common/toolbar/dialogos/dialogo-buscador.component';
import { DialogoCalendarComponent } from './common/toolbar/dialogos/dialogo-calendar.component';
import { AtencionReclamosComponent } from './reclamos/atencion-reclamos/atencion-reclamos.component';
import { AtencionReclamosEnotriaComponent } from './reclamos/atencion-reclamos/atencion-reclamos-enotria.component';
import { AtencionReclamosEnotriaOneComponent } from './reclamos/atencion-reclamos/atencion-reclamos-enotria-one.component';
import { PieAvanceFechaComponent } from './common/amedida/pie-avance-fecha/pie-avance-fecha.component';
import { ToolbarComponent } from './common/toolbar/toolbar.component';
import { DesignTablaComponent } from './reportes/design-tabla/design-tabla.component';
import { DialogoAgregarColumnasComponent } from './common/dialogo/dialogo-agregar-columnas.component';
import { DialogoGuardarComponent } from './common/dialogo/dialogo-guardar.component';
import { TrackingComponent } from './distrib/tracking/tracking.component';
import { TrackingTarjetaComponent } from './distrib/tracking/tracking-tarjeta.component';
import { TrackingCourierTarjetaComponent } from './distrib/tracking/tracking-courier-tarjeta.component';
import { TrackingTarjetaTabComponent } from './distrib/tracking/tracking-tarjeta-tab.component';
import { TrackingCourierTarjetaAvanceComponent } from './distrib/tracking/tracking-courier-tarjeta-avance.component';
import { TrackingCourierComponent } from './distrib/tracking-courier/tracking-courier.component';

// PROYECTO DE PAQUETERIA

import { PedidosComponent } from './pedidos/pedidos.component';
import { NewOrdersComponent } from './nuevo-pedido/new-orders.component';



@NgModule({
  declarations: [

 // PROYECTO PAQUETERIA
    PedidosComponent,
    NewOrdersComponent,

 // PROYECTO EDI

    AppComponent,
    LoginComponent,
    OriginComponent,
    NavMainComponent,
    DemoComponent,
    CreacionComponent,
    CrearNuevaComponent,
    CrearDetalleComponent,
    AsignacionComponent,
    AsignarNuevaComponent,
    AsignarDetalleComponent,
    DialogoComponent,
    DialogoVisibilidadComponent,
    DialogoImportarExcelComponent,
    DialogoEdicionTablaComponent,
    DialogoRelacionarComponent,
    CourierComponent,
    CourierAvanceComponent,
    CourierCargaComponent,
    CourierDetalleComponent,
    CourierLogComponent,
    CourierAvanceDetalleComponent,
    CourierLogDetalleComponent,
    EficienciaComponent,
    EfectividadComponent,
    InconsistenciaComponent,
    ToolbarChartComponent,
    BarChartComponent,
    LineChartComponent,
    PieChartComponent,
    // BuscadorComponent,
    DialogoBuscadorComponent,
    DialogoCalendarComponent,
    AtencionReclamosComponent,
    AtencionReclamosEnotriaComponent,
    AtencionReclamosEnotriaOneComponent,
    PieAvanceFechaComponent,
    ToolbarComponent,
    DesignTablaComponent,
    DialogoAgregarColumnasComponent,
    DialogoGuardarComponent,
    TrackingComponent,
    TrackingTarjetaComponent,
    TrackingCourierTarjetaComponent,
    TrackingTarjetaTabComponent,
    TrackingCourierTarjetaAvanceComponent,
    TrackingCourierComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    FormsModule,
  ],
  providers: [
   /*  { provide: NgbDateParserFormatter, useClass: DateParserFormatter },
    I18n, 
    { provide: NgbDatepickerI18n, useClass: DateI18nFormater }*/
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
