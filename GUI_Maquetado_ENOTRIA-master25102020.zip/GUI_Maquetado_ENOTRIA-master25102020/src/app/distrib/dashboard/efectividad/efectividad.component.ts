import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-efectividad',
  templateUrl: './efectividad.component.html',
  styleUrls: ['./efectividad.component.scss']
})
export class EfectividadComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  chartTipo = "bar" // bar, pie,line
  clickChangeTipo(ev){
    this.chartTipo = ev;
    console.log(ev)
  }
  nivel = 1
  clickChangeNivel(n){
    this.nivel = n
  }





  // FILTRO
  filtroHidden = true
  filtroToggle() {
    this.filtroHidden = !this.filtroHidden
  }

  id_bar = [1, 2, 3]
  id_dou = [4, 5, 6]
  // DATOS DEL CHART 1
  activo: string = "B1"

  mostrar() {
    var Opciones = (document.getElementById("tipo")) as HTMLSelectElement;
    var x = Opciones.value;
    this.activo = x;
  }
  dataBar1 = {
    "id": 1,
    "titulo": "Efectividad",
    "cantidad-barras": 2,
    "leyenda": {
      "l1": "Entrega",
      "l2": "Motivo"
    },
    "colores": {
      "color1": "#579AF1",
      "color2": "#8FBF55",
    },
    "data":
      [
        {
          "label": "Enero",
          "cantidad1": 4079,
          "cantidad2": 882,
        },
        {
          "label": "Febrero",
          "cantidad1": 5727,
          "cantidad2": 532,
        },
        {
          "label": "Marzo",
          "cantidad1": 6122,
          "cantidad2": 712,
        },
      ]
  }

  dataBar2 = {
    "id": 2,
    "titulo": "Efectividad + Click en Motivo",
    "cantidad-barras": 3,
    "leyenda": {
      "l1": "Sello",
      "l2": "Dirección Incompleta",
      "l3": "Dirección No Existe"
    },
    "colores": {
      "color1": "#579AF1",
      "color2": "#8FBF55",
      "color3": "#FAB445"
    },
    "data":
      [
        {
          "label": "Enero",
          "cantidad1": 10,
          "cantidad2": 513,
          "cantidad3": 359,
        },
        {
          "label": "Febrero",
          "cantidad1": 25,
          "cantidad2": 312,
          "cantidad3": 195,
        },
        {
          "label": "Marzo",
          "cantidad1": 15,
          "cantidad2": 479,
          "cantidad3": 218,
        },
      ]
  }

  dataPie = [
    {
      "titulo": "Enero",
      "data":
        [
          {
            "label": "Entrega",
            "color": "#579AF1",
            "cantidad": 4079,
          },
          {
            "label": "Motivo",
            "color": "#8FBF55",
            "cantidad": 882
          }
        ],
    },
    {
      "titulo": "Febrero",
      "data":
        [
          {
            "label": "Entrega",
            "color": "#579AF1",
            "cantidad": 5727,
          },
          {
            "label": "Motivo",
            "color": "#8FBF55",
            "cantidad": 532
          }
        ],
    },
    {
      "titulo": "Marzo",
      "data":
        [
          {
            "label": "Entrega",
            "color": "#579AF1",
            "cantidad": 6122,
          },
          {
            "label": "Motivo",
            "color": "#8FBF55",
            "cantidad": 712
          }
        ],
    }
  ]

  dataPie2 = [
    {
      "titulo": "Enero",
      "data":
        [
          {
            "label": "Entrega",
            "color": "#579AF1",
            "cantidad": 10,
          },
          {
            "label": "Motivo",
            "color": "#8FBF55",
            "cantidad": 513
          },
          {
            "label": "Motivo",
            "color": "#FAB445",
            "cantidad": 359
          }
        ],
    },
    {
      "titulo": "Febrero",
      "data":
        [
          {
            "label": "Entrega",
            "color": "#579AF1",
            "cantidad": 25,
          },
          {
            "label": "Motivo",
            "color": "#8FBF55",
            "cantidad": 312
          },
          {
            "label": "Motivo",
            "color": "#FAB445",
            "cantidad": 195
          }
        ],
    },
    {
      "titulo": "Marzo",
      "data":
        [
          {
            "label": "Entrega",
            "color": "#579AF1",
            "cantidad": 15,
          },
          {
            "label": "Motivo",
            "color": "#8FBF55",
            "cantidad": 479
          },
          {
            "label": "Motivo",
            "color": "#FAB445",
            "cantidad": 218
          }
        ],
    }
  ]

  ids = [1, 2, 3, 4, 5, 6]
}
