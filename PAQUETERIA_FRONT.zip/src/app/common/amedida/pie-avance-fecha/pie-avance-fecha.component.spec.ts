import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PieAvanceFechaComponent } from './pie-avance-fecha.component';

describe('PieAvanceFechaComponent', () => {
  let component: PieAvanceFechaComponent;
  let fixture: ComponentFixture<PieAvanceFechaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PieAvanceFechaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PieAvanceFechaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
