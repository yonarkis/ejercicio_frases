import { User } from './user.model';

export class Session {

 
  public lastName : string;
  public firstName : string;
  public token : string;
  public user : string;
  public userType: number;
  public opciones: any[];
}
