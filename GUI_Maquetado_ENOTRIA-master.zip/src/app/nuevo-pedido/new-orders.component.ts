import { Component, OnInit } from '@angular/core';
import {NgbModal, ModalDismissReasons, NgbModalOptions} from '@ng-bootstrap/ng-bootstrap';
import {NgbCalendar, NgbDateStruct, NgbProgressbar} from '@ng-bootstrap/ng-bootstrap';
import { Router, ActivatedRoute, Params} from '@angular/router';
import { OrderService } from '../services/orders.services'
import { from } from 'rxjs';
import { NgForm } from "@angular/forms";


type order = {
    "customerType": String,
    "shipmentType": String,
    "pickupType": String,
    "epicorProduct" : String,
    "pickupData": {
        "personDetails": {
            "fullName": String,
            "documentType": String,
            "documentId": Number,
            "phoneNumber": Number
        },
        "addressDetails": {
            "department": String,
            "province": String,
            "district": String,
            "urbanization": String,
            "housingType": String,
            "routeType": String,
            "address": String,
            "instructions": String
        }
    },
    "deliveryType": String,
    "deliveryData": {
        "personDetails": {
            "fullName": String,
            "documentType": String,
            "documentId": Number,
            "phoneNumber": Number
        },
        "addressDetails": {
            "department": String,
            "province": String,
            "district": String,
            "urbanization": String,
            "housingType": String,
            "routeType": String,
            "address": String,
            "instructions": String
        }
    },
    "packageType": String,
    "packageData": {
        "long": {
            "unit": String,
            "value": Number
        },
        "width": {
            "unit": String,
            "value": Number
        },
        "height": {
            "unit": String,
            "value": Number
        },
        "weight": {
            "unit": String,
            "value": Number
        },
        "aproxVolume": {
            "unit": String,
            "value": Number
        },
        "description": String
    },
    "isExpress": Boolean,
    "programmedDate": Date
}

// @Component({
//   selector: 'ngbd-nav-basic',
//   templateUrl: './nav-basic.html'
// })

@Component({
  selector: 'app-demo',
  templateUrl: './new-orders.component.html',
  styleUrls: ['./new-orders.component.scss'],
  providers: [OrderService]

})
export class NewOrdersComponent implements OnInit {

  constructor( private orderService: OrderService ) { }
  // constructor(  ) { }
  ngOnInit() {
    this.getDeparment(); this.getDeparmentDelivey();
  }


  isShownOrdersForms : boolean = false;

  isShownOrdersEmpty: boolean = true;

  isShownOrdersConfirm: boolean = false;

  isShownDropdown : boolean = false; // hidden by default

  isShownShippingType : boolean = false; // hidden by default

  isShownDivWidespread : boolean = false; // hidden by default

  isShownDivImgClient : boolean = true;
  isHideDivImgClient : boolean = false;

  isShownDivImgInternal : boolean = true;
  isHideDivImgInternal : boolean = false;

  addClassClient: boolean = true;
  addClassInternal: boolean = true;

  // opciones de tipo de envio

  addClassSendOrdersLima: boolean = true;
  addClassSendOrdersProvince: boolean = true;
  addClassSendOrdersInt: boolean = true;

  isShownDivImgLima : boolean = true;
  isHideDivImgLima : boolean = false;

  isShownDivImgProvince : boolean = true;
  isHideDivImgProvince : boolean = false;

  isShownDivImgInt : boolean = true;
  isHideDivImgInt : boolean = false;

// opciones de paqueteria

  addClassDocument: boolean = true;
  addClassPackage: boolean = true;
  addClassValued: boolean = true;

  isShownDivImgDocument : boolean = true;
  isHideDivImgDocument : boolean = false;

  isShownDivImgPackage : boolean = true;
  isHideDivImgPackage : boolean = false;

  isShownDivImgValued : boolean = true;
  isHideDivImgValued : boolean = false;



  ShownOrdersForms(){
    this.isShownOrdersForms = true;
    this.isShownOrdersEmpty = false;
    this.isShownOrdersConfirm = false;
  }

  tetstMane = [];
  // orden.epicorProduct

  OrdersConfirm(){
    this.isShownOrdersConfirm = true;
    this.isShownOrdersForms = false;

  this.packageDataLong.value 


    // this.tetstMane = this.orden.epicorProduct
    // console.log(this.tetstMane, "test")
  }

  a : number;
  b : number;
  c : number;

  // packageDataAproxVolume.value = 2

  tettttt(){

    // var a =  this.packageDataLong.value
    // var b =  this.packageDataWidth.value
    // var c =  this.packageDataHeight.value

    // var d = a + b + c

    // console.log(a)
  }
  editOrders(){
    this.isShownOrdersForms = true;
    this.isShownOrdersConfirm = false;

  }


  showSendOrders(index){
    this.isShownDropdown = true;
    if(index === 1){

      this.addClassClient = false;
      this.addClassInternal = true;

      this.isShownDivImgClient = false
      this.isHideDivImgClient = true ;

      this.isShownDivImgInternal = true
      this.isHideDivImgInternal = false ;

    }
    if(index === 2){

      this.addClassClient = true;
      this.addClassInternal = false;

      this.isShownDivImgClient = true;
      this.isHideDivImgClient = false;

      this.isShownDivImgInternal = false;
      this.isHideDivImgInternal = true;
    }
  }

  showSendDivWidespread(index){
    this.isShownDivWidespread = true;

    if(index === 1){
      this.addClassSendOrdersLima = false
      this.addClassSendOrdersProvince = true
      this.addClassSendOrdersInt = true

      this.isShownDivImgLima = false;
      this.isHideDivImgLima = true;

      this.isShownDivImgProvince = true;
      this.isHideDivImgProvince = false;

      this.isShownDivImgInt = true;
      this.isHideDivImgInt = false;
    }

    if(index === 2){
      this.addClassSendOrdersLima = true
      this.addClassSendOrdersProvince = false
      this.addClassSendOrdersInt = true

      this.isShownDivImgLima = true;
      this.isHideDivImgLima = false;

      this.isShownDivImgProvince = false;
      this.isHideDivImgProvince = true;

      this.isShownDivImgInt = true;
      this.isHideDivImgInt = false;
    }

    if(index === 3){
      this.addClassSendOrdersLima = true
      this.addClassSendOrdersProvince = true
      this.addClassSendOrdersInt = false

      this.isShownDivImgLima = true;
      this.isHideDivImgLima = false;

      this.isShownDivImgProvince = true;
      this.isHideDivImgProvince = false;

      this.isShownDivImgInt = false;
      this.isHideDivImgInt = true;
    }

  }

  showSendPackage(index){
    if(index === 1){
      this.addClassDocument = false
      this.addClassPackage = true
      this.addClassValued = true

      this.isShownDivImgDocument = false;
      this.isHideDivImgDocument = true;

      this.isShownDivImgPackage = true;
      this.isHideDivImgPackage = false;

      this.isShownDivImgValued = true;
      this.isHideDivImgValued = false;
    }

    if(index === 2){
      this.addClassDocument = true
      this.addClassPackage = false
      this.addClassValued = true

      this.isShownDivImgDocument = true;
      this.isHideDivImgDocument = false;

      this.isShownDivImgPackage = false;
      this.isHideDivImgPackage = true;

      this.isShownDivImgValued = true;
      this.isHideDivImgValued = false;
    }

    if(index === 3){
      this.addClassDocument = true
      this.addClassPackage = true
      this.addClassValued = false

      this.isShownDivImgDocument = true;
      this.isHideDivImgDocument = false;

      this.isShownDivImgPackage = true;
      this.isHideDivImgPackage = false;

      this.isShownDivImgValued = false;
      this.isHideDivImgValued = true;
    }

  }

  changeDropdownProduct(){
    this.isShownShippingType = true;
  }


  assignValue(key, value) {
    this.orden[key] = value;
  }

  ubigeoDeparment = []
  ubigeoProvince = []
  ubigeoDistrict = []

  ubigeoDeparmentDelivery = []
  ubigeoProvinceDelivery = []
  ubigeoDistrictDelivery = []

  getDeparment() {
    this.orderService.getDeparment().subscribe((res) => {
       this.ubigeoDeparment = res;
      });
  }

  getProvince(id_deparment) {

    id_deparment = this.pickupAddressDetails.department;
    this.orderService.getProvince(id_deparment).subscribe((res) => {
       this.ubigeoProvince = res;
    });
  }

  getDistrict(id_province) {

    if(id_province === 1){
      id_province = this.pickupAddressDetails.province = "";
      this.orderService.getDistrictDelivery(id_province).subscribe((res) => {
         this.ubigeoDistrictDelivery = res;
      });
    }

    id_province = this.pickupAddressDetails.province;
    this.orderService.getDistrict(id_province).subscribe((res) => {
       this.ubigeoDistrict = res;
    });
  }

  getDeparmentDelivey() {
    this.orderService.getDeparment().subscribe((res) => {
       this.ubigeoDeparmentDelivery = res;
       console.log(this.ubigeoDeparmentDelivery)
      });
  }

  getProvinceDelivery(id_deparment_delivery) {

    id_deparment_delivery = this.deliveryAddressDetails.department;
    this.orderService.getProvinceDelivery(id_deparment_delivery).subscribe((res) => {
       this.ubigeoProvinceDelivery = res;
    });
  }

  getDistrictDelivery(id_province_delivery) {


    if(id_province_delivery === 1){
      id_province_delivery = this.deliveryAddressDetails.province = "";
      this.orderService.getDistrictDelivery(id_province_delivery).subscribe((res) => {
         this.ubigeoDistrictDelivery = res;
      });
    }

    id_province_delivery = this.deliveryAddressDetails.province;
    this.orderService.getDistrictDelivery(id_province_delivery).subscribe((res) => {
       this.ubigeoDistrictDelivery = res;
    });
  }




  // orden

  orden: Partial<order> = {};

  // data de recogo

  pickupData: Partial<order["pickupData"]> ={}

  pickupAddressDetails: Partial<order["pickupData"]["addressDetails"]> = {}

  pickupPersonDetails: Partial<order["pickupData"]["personDetails"]> = {}

  // data de entrega

  deliveryData: Partial<order["deliveryData"]> = {}

  deliveryAddressDetails: Partial<order["deliveryData"]["addressDetails"]> = {}

  deliveryPersonDetails: Partial<order["deliveryData"]["personDetails"]> = {}

  // data de paquete

  packageData: Partial<order["packageData"]> = {}

  packageDataLong: Partial<order["packageData"]["long"]> = {}

  packageDataWidth: Partial<order["packageData"]["width"]> = {}

  packageDataHeight: Partial<order["packageData"]["height"]> = {}

  packageDataWeight: Partial<order["packageData"]["weight"]> = {}

  packageDataAproxVolume: Partial<order["packageData"]["aproxVolume"]> = {}

}

