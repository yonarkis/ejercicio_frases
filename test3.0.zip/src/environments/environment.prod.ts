export const environment = {
  production: true,
  entorno:"Produccion",//IPS DE PRODUCCION

  
  //ENOTRIA QA
  UrlServiceAPIOrders:"http://172.25.11.5:4001/api/",
  
  // localhost:3000/api/v1/order/newOrder

  version: '29/10/2020 - 16:46'
};