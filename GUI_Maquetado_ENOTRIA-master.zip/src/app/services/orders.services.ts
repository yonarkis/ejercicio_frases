import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from '../../environments/environment';

import { Deparment } from '../models/deparment.models'
import { Province } from '../models/province.models'
import { District } from '../models/district.models'


@Injectable({
    providedIn: 'root'
})

export class OrderService {
    private basePath = environment.UrlServiceAPIOrders + "v1/order/";
    private paramsPath = environment.UrlServiceAPIOrders + "v1/param/";

    selectedDeparment: Deparment;
    deparment: Deparment[];

    selectedProvince: Province;
    province: Province[];

    selectedDistrict: District;
    district: District[];

    constructor(private http: HttpClient) { }

    register(orden: any): Observable<any> {

        let headers = new HttpHeaders()
            .set('Content-Type', 'application/json');

        return this.http
            .post<any>(
                this.basePath + 'newOrder', orden, { headers: headers }
            )
            .pipe(
                map(res => {
                    return res;
                })
            );
    }


    getDeparment(): Observable<any> {

        let headers = new HttpHeaders()
            .set('Content-Type', 'application/json');

        return this.http
            .get<Deparment[]>(
                this.paramsPath + 'getUbigeo?type=deparment', { headers: headers }
            )
            .pipe(
                map(res => {
                    return res;
                })
            );
    }

    getProvince(id_deparment): Observable<any> {

        let headers = new HttpHeaders()
            .set('Content-Type', 'application/json');

        return this.http
            .get<Province[]>(
                this.paramsPath + 'getUbigeo?type=province&ubigeoContainerId='+id_deparment, { headers: headers }
            )
            .pipe(
                map(res => {
                    return res;
                })
            );
    }

    getDistrict(id_province): Observable<any> {

        let headers = new HttpHeaders()
            .set('Content-Type', 'application/json');

            console.log(id_province)

        return this.http
            .get<District[]>(
                this.paramsPath + 'getUbigeo?type=district&ubigeoContainerId='+id_province, { headers: headers }
            )
            .pipe(
                map(res => {
                    return res;
                })
            );
    }

    getDeparmentDelivery(): Observable<any> {

        let headers = new HttpHeaders()
            .set('Content-Type', 'application/json');

        return this.http
            .get<Deparment[]>(
                this.paramsPath + 'getUbigeo?type=deparment', { headers: headers }
            )
            .pipe(
                map(res => {
                    return res;
                })
            );
    }

    getProvinceDelivery(id_deparment): Observable<any> {

        let headers = new HttpHeaders()
            .set('Content-Type', 'application/json');

        return this.http
            .get<Province[]>(
                this.paramsPath + 'getUbigeo?type=province&ubigeoContainerId='+id_deparment, { headers: headers }
            )
            .pipe(
                map(res => {
                    return res;
                })
            );
    }

    getDistrictDelivery(id_province): Observable<any> {

        let headers = new HttpHeaders()
            .set('Content-Type', 'application/json');

            console.log(id_province)

        return this.http
            .get<District[]>(
                this.paramsPath + 'getUbigeo?type=district&ubigeoContainerId='+id_province, { headers: headers }
            )
            .pipe(
                map(res => {
                    return res;
                })
            );
    }

    getRouteType(): Observable<any> {

        let headers = new HttpHeaders()
            .set('Content-Type', 'application/json');

        return this.http
            .get<any[]>(
                this.paramsPath + 'getParams?types=routeType', { headers: headers }
            )
            .pipe(
                map(res => {
                    return res;
                })
            );
    }

    getHousingType(): Observable<any> {

        let headers = new HttpHeaders()
            .set('Content-Type', 'application/json');

        return this.http
            .get<any[]>(
                this.paramsPath + 'getParams?types=housingType', { headers: headers }
            )
            .pipe(
                map(res => {
                    return res;
                })
            );
    }

    getDocumentType(): Observable<any> {

        let headers = new HttpHeaders()
            .set('Content-Type', 'application/json');

        return this.http
            .get<any[]>(
                this.paramsPath + 'getParams?types=documentType', { headers: headers }
            )
            .pipe(
                map(res => {
                    return res;
                })
            );
    }

    getProducts(): Observable<any> {

        let headers = new HttpHeaders()
            .set('Content-Type', 'application/json');

        return this.http
            .get<any[]>(
                this.paramsPath + 'getProducts', { headers: headers }
            )
            .pipe(
                map(res => {
                    return res;
                })
            );
    }

}