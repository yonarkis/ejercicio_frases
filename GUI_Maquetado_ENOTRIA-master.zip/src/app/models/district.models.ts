export class District {
    constructor(id = "", name = "", department_id = "", province_id = "") {
      this.id = id;
      this.name = name;
      this.department_id = department_id;
      this.province_id = province_id;
    }
  
    id: string;
    name: string;
    department_id: string;
    province_id: string;
  }
  