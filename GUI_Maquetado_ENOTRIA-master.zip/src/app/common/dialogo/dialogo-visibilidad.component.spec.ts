import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DialogoVisibilidadComponent } from './dialogo-visibilidad.component';

describe('DialogoVisibilidadComponent', () => {
  let component: DialogoVisibilidadComponent;
  let fixture: ComponentFixture<DialogoVisibilidadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DialogoVisibilidadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DialogoVisibilidadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
