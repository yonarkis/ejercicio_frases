import { Component, OnInit, Input } from '@angular/core';
import { Chart } from 'chart.js';

@Component({
  selector: 'app-pie-chart',
  templateUrl: './pie-chart.component.html',
  styleUrls: ['./pie-chart.component.scss']
})
export class PieChartComponent implements OnInit {

  mychart: any = 1;
  @Input() data: any;
  @Input() id: any;

  constructor() { }


  ngOnInit() {
  }

  ngAfterViewInit() {

    var titulo = this.data["titulo"];
    var labels = [];
    var datos = [];
    var colors = [];
    var tienda = this.data["data"];
    let cont: number = 0;

    for (let index = 0; index < tienda.length; index++) {
      labels.push(tienda[index]["label"]);
      colors.push(tienda[index]["color"]);
      var num = parseInt(tienda[index]["cantidad"], 10);
      cont = cont + num;
    }

    for (let index = 0; index < tienda.length; index++) {
      var dato = tienda[index]["cantidad"];
      var porcentaje = (dato/cont)*100;
      datos.push(porcentaje.toFixed(1));
    }
    
    var data = {
      labels: labels,
      datasets: [{
        data: datos,
        fill: false,
        backgroundColor: colors
      }]
    }

    this.mychart = new Chart('dou' + this.id, {
      type: 'doughnut',
      data: data,
      options: {
        legend: {
          display: true,
          position: 'bottom',
          labels: {
            fontColor: "#000080",
          }
        },
        responsive: true,
        maintainAspectRatio: false,
        title: {
          display: true,
          text: titulo
        },
      }
    });
    
  }

}
