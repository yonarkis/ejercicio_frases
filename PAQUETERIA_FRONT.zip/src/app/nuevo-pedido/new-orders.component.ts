import { Component, OnInit } from '@angular/core';
import { OrderService } from '../services/orders.services';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { flatMap } from 'rxjs/operators';

type order = {
  "customerType": String,
  "shipmentType": String,
  "epicorProduct": String,
  "pickupType": String,
  "pickupData": {
    "personDetails": {
      "fullName": String,
      "documentType": String,
      "documentId": String,
      "phoneNumber": String,
      "personId": String
    },
    "addressDetails": {
      "department": String,
      "province": String,
      "district": String,
      "urbanization": String,
      "housingType": String,
      "routeType": String,
      "address": String,
      "instructions": String,
      "officeArea": String,
      "officeId": String
    }
  },
  "deliveryType": String,
  "deliveryData": {
    "personDetails": {
      "fullName": String,
      "documentType": String,
      "documentId": String,
      "phoneNumber": String,
      "personId": String
    },
    "addressDetails": {
      "department": String,
      "province": String,
      "district": String,
      "urbanization": String,
      "housingType": String,
      "routeType": String,
      "address": String,
      "instructions": String,
      "officeArea": String,
      "officeId": String
    }
  },
  "packageType": String,
  "packageData": {
    "long": {
      "unit": String,
      "value": Number
    },
    "width": {
      "unit": String,
      "value": Number
    },
    "height": {
      "unit": String,
      "value": Number
    },
    "weight": {
      "unit": String,
      "value": Number
    },
    "aproxVolume": {
      "unit": String,
      "value": Number
    },
    "description": String
  },
  "isExpress": Boolean,
  "programmedDate": Date,
  "programmedTime": Date
};

// @Component({
//   selector: 'ngbd-nav-basic',
//   templateUrl: './nav-basic.html'
// })

@Component({
  selector: 'app-demo',
  templateUrl: './new-orders.component.html',
  styleUrls: ['./new-orders.component.scss'],
  providers: [OrderService],
})
export class NewOrdersComponent implements OnInit {

  constructor(private orderService: OrderService) { }
  // constructor(  ) { }
  ngOnInit() {
    this.getDeparment(); this.getDeparmentDelivey(); this.getRouteType(); this.getDocumentType(); this.getHousingType(); this.getProduct()
  }


  isShownOrdersForms: boolean = false;

  isShownOrdersEmpty: boolean = true;

  isShownOrdersConfirm: boolean = false;

  isShownDropdown: boolean = false; // hidden by default

  isShownShippingType: boolean = false; // hidden by default

  isShownDivWidespread: boolean = false; // hidden by default

  isShownDivImgClient: boolean = true;
  isHideDivImgClient: boolean = false;

  isShownDivImgInternal: boolean = true;
  isHideDivImgInternal: boolean = false;

  addClassClient: boolean = true;
  addClassInternal: boolean = true;

  // opciones de tipo de envio

  addClassSendOrdersLima: boolean = true;
  addClassSendOrdersProvince: boolean = true;
  addClassSendOrdersInt: boolean = true;

  isShownDivImgLima: boolean = true;
  isHideDivImgLima: boolean = false;

  isShownDivImgProvince: boolean = true;
  isHideDivImgProvince: boolean = false;

  isShownDivImgInt: boolean = true;
  isHideDivImgInt: boolean = false;

  // opciones de paqueteria

  addClassDocument: boolean = true;
  addClassPackage: boolean = true;
  addClassValued: boolean = true;

  isShownDivImgDocument: boolean = true;
  isHideDivImgDocument: boolean = false;

  isShownDivImgPackage: boolean = true;
  isHideDivImgPackage: boolean = false;

  isShownDivImgValued: boolean = true;
  isHideDivImgValued: boolean = false;

  // opciones tipo paquete

  disabledElementDocumentPackage: boolean = false;

  disabledfieldProgramming : boolean = false;

  weightValue : boolean = true;

  filtersHidden : boolean = false;


  ShownOrdersForms() {
    this.isShownOrdersForms = true;
    this.isShownOrdersEmpty = false;
    this.isShownOrdersConfirm = false;
  }

  isValidator : boolean = false;
  OrdersConfirm() {


    if(!this.orden.packageData.weight.value || this.orden.packageData.weight.value === undefined){
        this.weightValue = false;
    } else{
        this.weightValue = true;
    }
    //  console.log(this.orden.isExpress)

    // if(this.orden.isExpress === false){
    //   if(!this.orden.programmedDate  || this.orden.programmedDate === undefined){
    //     this.isValidator = true
    //   }else{
    //     this.isValidator = false
    //   }
    // } else {
    //     this.isValidator = false
    // }

    this.isShownOrdersConfirm = true;
    this.isShownOrdersForms = false;
  }

  editOrders() {

    console.log(this.orden.pickupData.addressDetails.department)

    this.isShownOrdersForms = true;
    this.isShownOrdersConfirm = false;
  }

  showSendOrders(index) {
    this.isShownDropdown = true;
    if (index === 1) {

      this.addClassClient = false;
      this.addClassInternal = true;

      this.isShownDivImgClient = false
      this.isHideDivImgClient = true;

      this.isShownDivImgInternal = true
      this.isHideDivImgInternal = false;

    }
    if (index === 2) {

      this.addClassClient = true;
      this.addClassInternal = false;

      this.isShownDivImgClient = true;
      this.isHideDivImgClient = false;

      this.isShownDivImgInternal = false;
      this.isHideDivImgInternal = true;
    }
  }

  showSendDivWidespread(index) {
    this.isShownDivWidespread = true;

    if (index === 1) {
      this.addClassSendOrdersLima = false
      this.addClassSendOrdersProvince = true
      this.addClassSendOrdersInt = true

      this.isShownDivImgLima = false;
      this.isHideDivImgLima = true;

      this.isShownDivImgProvince = true;
      this.isHideDivImgProvince = false;

      this.isShownDivImgInt = true;
      this.isHideDivImgInt = false;

    }

    if (index === 2) {
      this.addClassSendOrdersLima = true
      this.addClassSendOrdersProvince = false
      this.addClassSendOrdersInt = true

      this.isShownDivImgLima = true;
      this.isHideDivImgLima = false;

      this.isShownDivImgProvince = false;
      this.isHideDivImgProvince = true;

      this.isShownDivImgInt = true;
      this.isHideDivImgInt = false;

    }

    if (index === 3) {
      this.addClassSendOrdersLima = true
      this.addClassSendOrdersProvince = true
      this.addClassSendOrdersInt = false

      this.isShownDivImgLima = true;
      this.isHideDivImgLima = false;

      this.isShownDivImgProvince = true;
      this.isHideDivImgProvince = false;

      this.isShownDivImgInt = false;
      this.isHideDivImgInt = true;
    }

  }

  showSendPackage(index) {
    if (index === 1) {
      this.addClassDocument = false
      this.addClassPackage = true
      this.addClassValued = true

      this.isShownDivImgDocument = false;
      this.isHideDivImgDocument = true;

      this.isShownDivImgPackage = true;
      this.isHideDivImgPackage = false;

      this.isShownDivImgValued = true;
      this.isHideDivImgValued = false;

      this.disabledElementDocumentPackage = true;
      this.orden.packageData.long.value = undefined
      this.orden.packageData.width.value = undefined
      this.orden.packageData.height.value = undefined
      this.orden.packageData.weight.value = undefined
      this.orden.packageData.aproxVolume.value = undefined
    }

    if (index === 2) {
      this.addClassDocument = true
      this.addClassPackage = false
      this.addClassValued = true

      this.isShownDivImgDocument = true;
      this.isHideDivImgDocument = false;

      this.isShownDivImgPackage = false;
      this.isHideDivImgPackage = true;

      this.isShownDivImgValued = true;
      this.isHideDivImgValued = false;

      this.disabledElementDocumentPackage = false;
    }

    if (index === 3) {
      this.addClassDocument = true
      this.addClassPackage = true
      this.addClassValued = false

      this.isShownDivImgDocument = true;
      this.isHideDivImgDocument = false;

      this.isShownDivImgPackage = true;
      this.isHideDivImgPackage = false;

      this.isShownDivImgValued = false;
      this.isHideDivImgValued = true;

      this.disabledElementDocumentPackage = false;
    }

  }

  changeDropdownProduct() {
    this.isShownShippingType = true;
  }

  assignValue(key, value) {
    this.orden[key] = value;
    console.log(this.orden);
  }

  deliveryPhoneNumberOffice : string;
  deliveryInstructionsOffice : string;
  clearDeliveryFormOffice(){
     this.orden.deliveryData.addressDetails.officeId = undefined
     this.orden.deliveryData.addressDetails.officeArea = undefined
     this.orden.deliveryData.personDetails.personId = undefined
     this.deliveryPhoneNumberOffice = undefined
     this.deliveryInstructionsOffice = undefined
  }
  
  clearDeliveryFormOutOffice(){

    this.orden.deliveryData.addressDetails.routeType = undefined
    this.orden.deliveryData.addressDetails.address = undefined
    this.orden.deliveryData.addressDetails.department = undefined
    this.orden.deliveryData.addressDetails.province = undefined
    this.orden.deliveryData.addressDetails.district = undefined
    this.orden.deliveryData.addressDetails.urbanization = undefined
    this.orden.deliveryData.addressDetails.housingType = undefined
    this.orden.deliveryData.personDetails.fullName = undefined
    this.orden.deliveryData.personDetails.documentType = undefined
    this.orden.deliveryData.personDetails.documentId = undefined
    this.orden.deliveryData.personDetails.phoneNumber = undefined
    this.orden.deliveryData.addressDetails.instructions = undefined
 }

 pickupPhoneNumberOffice : string;
 pickupInstructionsOffice : string;
 clearPickupFormOffice(){
    this.orden.pickupData.addressDetails.officeId = undefined
    this.orden.pickupData.addressDetails.officeArea = undefined
    this.orden.pickupData.personDetails.personId = undefined
    this.pickupPhoneNumberOffice = undefined
    this.pickupInstructionsOffice = undefined
 }
 
 clearPickupFormOutOffice(){

   this.orden.pickupData.addressDetails.routeType = undefined
   this.orden.pickupData.addressDetails.address = undefined
   this.orden.pickupData.addressDetails.department = undefined
   this.orden.pickupData.addressDetails.province = undefined
   this.orden.pickupData.addressDetails.district = undefined
   this.orden.pickupData.addressDetails.urbanization = undefined
   this.orden.pickupData.addressDetails.housingType = undefined
   this.orden.pickupData.personDetails.fullName = undefined
   this.orden.pickupData.personDetails.documentType = undefined
   this.orden.pickupData.personDetails.documentId = undefined
   this.orden.pickupData.personDetails.phoneNumber = undefined
   this.orden.pickupData.addressDetails.instructions = undefined
}

  ubigeoDeparment = []
  ubigeoProvince = []
  ubigeoDistrict = []

  ubigeoDeparmentDelivery = []
  ubigeoProvinceDelivery = []
  ubigeoDistrictDelivery = []

  getDeparment() {
    this.orderService.getDeparment().subscribe((res) => {
      this.ubigeoDeparment = res;
      // this.orden.pickupData.addressDetails.department === "15"
    });
  }

  getProvince(id_deparment) {

    id_deparment = this.orden.pickupData.addressDetails.department;
    this.orderService.getProvince(id_deparment).subscribe((res) => {
      this.ubigeoProvince = res;
    });
  }

  getDistrict(id_province) {

    if (id_province === 1) {
      id_province = this.orden.pickupData.addressDetails.province = "";
      this.orderService.getDistrictDelivery(id_province).subscribe((res) => {
        this.ubigeoDistrictDelivery = res;
      });
    }

    id_province = this.orden.pickupData.addressDetails.province;
    this.orderService.getDistrict(id_province).subscribe((res) => {
      this.ubigeoDistrict = res;
    });
  }

  getDeparmentDelivey() {
    this.orderService.getDeparment().subscribe((res) => {
      this.ubigeoDeparmentDelivery = res;
    });
  }

  getProvinceDelivery(id_deparment_delivery) {
    id_deparment_delivery = this.orden.deliveryData.addressDetails.department;
    this.orderService.getProvinceDelivery(id_deparment_delivery).subscribe((res) => {
      this.ubigeoProvinceDelivery = res;
    });
  }

  getDistrictDelivery(id_province_delivery) {
    if (id_province_delivery === 1) {
      id_province_delivery = this.orden.deliveryData.addressDetails.province = "";
      this.orderService.getDistrictDelivery(id_province_delivery).subscribe((res) => {
        this.ubigeoDistrictDelivery = res;
      });
    }

    id_province_delivery = this.orden.deliveryData.addressDetails.province;
    this.orderService.getDistrictDelivery(id_province_delivery).subscribe((res) => {
      this.ubigeoDistrictDelivery = res;
    });
  }

  routeType = [];
  getRouteType() {
    this.orderService.getRouteType().subscribe((res) => {
      this.routeType = res;
      console.log(this.routeType, "tipo de via")
    });
  }

  housingType = [];
  getHousingType() {
    this.orderService.getHousingType().subscribe((res) => {
      this.housingType = res;
    });
  }

  documentType = [];
  getDocumentType() {
    this.orderService.getDocumentType().subscribe((res) => {
      this.documentType = res;
    });
  }

  epicorProduct = [];
  getProduct() {
    this.orderService.getProducts().subscribe((res) => {
      this.epicorProduct = res;
    });
  }

  submitForms() {
    this.orderService.register(this.orden).subscribe((res) => {
      console.log(res)
    });
    console.log(this.orden, "orden")
  }

  results = Number
  calculateVolumen() {
    const a = this.orden.packageData.long.value;
    const b = this.orden.packageData.width.value;
    const c = this.orden.packageData.height.value;
    const result: number =  <number>a * <number>b * <number>c;
    this.orden.packageData.aproxVolume.value = result;
  }

  changeCheck(){
    this.disabledfieldProgramming = !this.disabledfieldProgramming
    this.orden.isExpress = !this.orden.isExpress
    if(this.orden.programmedDate  || !this.orden.programmedDate === undefined){
      this.orden.programmedDate = undefined
    }
    
    if(this.orden.programmedTime  || !this.orden.programmedTime === undefined){
      this.orden.programmedTime= undefined
    }
    
  }

  // validaciones

  resultado: string;

  formularioContacto = new FormGroup({
    phoneNumber: new FormControl('', [Validators.required, Validators.minLength(10)]),
    mail: new FormControl('', [Validators.required, Validators.email]),
    mensaje: new FormControl('', [Validators.required, Validators.maxLength(500)])
  });

  submit() {
    if (this.formularioContacto.valid)
      this.resultado = "Todos los datos son válidos";
    else
      this.resultado = "Hay datos inválidos en el formulario";
  }

  // orden

  orden: Partial<order> = {
    "customerType": undefined,
    "shipmentType": undefined,
    "epicorProduct": undefined,
    "pickupType": 'in-office',
    "pickupData": {
      "personDetails": {
        "fullName": undefined,
        "documentType": undefined,
        "documentId": undefined,
        "phoneNumber": undefined,
        "personId": undefined
      },
      "addressDetails": {
        "department": undefined,
        "province": undefined,
        "district": undefined,
        "urbanization": undefined,
        "housingType": undefined,
        "routeType": undefined,
        "address": undefined,
        "instructions": undefined,
        "officeArea": undefined,
        "officeId": undefined
      }
    },
    "deliveryType": 'in-office',
    "deliveryData": {
      "personDetails": {
        "fullName": undefined,
        "documentType": undefined,
        "documentId": undefined,
        "phoneNumber": undefined,
        "personId": undefined
      },
      "addressDetails": {
        "department": undefined,
        "province": undefined,
        "district": undefined,
        "urbanization": undefined,
        "housingType": undefined,
        "routeType": undefined,
        "address": undefined,
        "instructions": undefined,
        "officeArea": undefined,
        "officeId": undefined
      }
    },
    "packageType": undefined,
    "packageData": {
      "long": {
        "unit": "cm",
        "value": undefined
      },
      "width": {
        "unit": "cm",
        "value": undefined
      },
      "height": {
        "unit": "cm",
        "value": undefined
      },
      "weight": {
        "unit": "kg",
        "value": undefined
      },
      "aproxVolume": {
        "unit": "cm3",
        "value": undefined
      },
      "description": undefined
    },
    "isExpress": false,
    "programmedDate": undefined,
    "programmedTime": undefined
  }



}

