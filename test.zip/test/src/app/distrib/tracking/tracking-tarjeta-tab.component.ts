import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-tracking-tarjeta-tab',
  templateUrl: './tracking-tarjeta-tab.component.html',
  styleUrls: ['./tracking-tarjeta-tab.component.scss']
})
export class TrackingTarjetaTabComponent implements OnInit {

  @Input() avance:number = 25
  @Input() label:string = "Test"
  @Input() color:string = "#f00"
  @Input() id:string = ""
  @Input() backColor:string = "#eee"
  @Input() background:string = "#fff"



  avance2 = 75
  complemento = 75
  avanceBind:string = "25 75"
  xxx = false
  constructor() { }

  ngOnInit() {
    this.setData()
  }

  // setFlecha(){
  //   return " transparent " + this.color + " transparent transparent"
  // }

  setData(){
    if (this.avance >= 0 && this.avance <= 100) {
      this.complemento = 100-this.avance
      console.log("1")
    } else {
      this.avance = 0
      this.complemento = 100
      this.label = "error data"
      console.log("2")
    }
    this.avanceBind = String(this.avance + " " + this.complemento)
    console.log(this.avanceBind)
    this.xxx = true
  }

}
