import { Component, OnInit, Input } from '@angular/core';
import { NgbModal, ModalDismissReasons, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';
import { NgbCalendar, NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { Router} from '@angular/router';

@Component({
  selector: 'app-dialogo-buscador',
  templateUrl: './dialogo-buscador.component.html',
  styleUrls: ['./dialogo-buscador.component.scss']
})
export class DialogoBuscadorComponent implements OnInit {

  @Input() titulo = "ejemplo"
  @Input() esPoco = false
  @Input() data = ["Lorem ipsum","Blandit turpis","Pharetra pharetra massa","Vitae justo eget magna","Sed tempus urna","Elit at imperdiet dui","Nisi est sit amet"]

  
  closeResult: string;
  modalOption: NgbModalOptions = {};

  constructor(public modalService: NgbModal) { }

  ngOnInit() {
  }

  /* Popup */
  openModalSmall(contenido) {
    this.modalOption.backdrop = 'static';
    this.modalOption.keyboard = false;
    this.modalService.open(contenido, this.modalOption).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }
  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  } open(content) {
    this.modalService.open(content);
  }
}