import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DialogoGuardarComponent } from './dialogo-guardar.component';

describe('DialogoGuardarComponent', () => {
  let component: DialogoGuardarComponent;
  let fixture: ComponentFixture<DialogoGuardarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DialogoGuardarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DialogoGuardarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
