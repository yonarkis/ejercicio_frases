import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eficiencia',
  templateUrl: './eficiencia.component.html',
  styleUrls: ['./eficiencia.component.scss']
})
export class EficienciaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  // FILTRO
  filtroHidden = true
  filtroToggle() {
    this.filtroHidden = !this.filtroHidden
  }

  id_bar = [1, 2, 3]
  ids = [1, 2, 3, 4, 5, 6]
  activo: string = "B1"

  mostrar() {
    var Opciones = (document.getElementById("tipo")) as HTMLSelectElement;
    var x = Opciones.value;
    this.activo = x;
  }

  chartTipo = "bar" // bar, pie,line
  clickChangeTipo(ev){
    this.chartTipo = ev;
    console.log(ev)
  }
  nivel = 1
  clickChangeNivel(n){
    this.nivel = n
  }


  dataBar1 = {
    "id": 1,
    "titulo": "Eficiencia",
    "cantidad-barras": 2,
    "leyenda": {
      "l1": "Dentro Fecha",
      "l2": "Fuera Fecha"
    },
    "colores": {
      "color1": "#579AF1",
      "color2": "#8FBF55",
    },
    "data":
      [
        {
          "label": "Enero",
          "cantidad1": 500,
          "cantidad2": 150,
        },
        {
          "label": "Febrero",
          "cantidad1": 3500,
          "cantidad2": 450,
        },
        {
          "label": "Marzo",
          "cantidad1": 4250,
          "cantidad2": 1100,
        },
      ]
  }

  dataBar2 = {
    "id": 2,
    "titulo": "Eficiencia + Click en Motivo",
    "cantidad-barras": 2,
    "leyenda": {
      "l1": "Dentro Fecha",
      "l2": "Fuera Fecha"
    },
    "colores": {
      "color1": "#579AF1",
      "color2": "#8FBF55",
    },
    "data":
      [
        {
          "label": "Enero",
          "cantidad1": 500,
          "cantidad2": 150,
        },
        {
          "label": "Febrero",
          "cantidad1": 3500,
          "cantidad2": 450,
        },
        {
          "label": "Marzo",
          "cantidad1": 4250,
          "cantidad2": 1100,
        },
      ]
  }

  dataBar3 = {
    "id": 1,
    "titulo": "",
    "cantidad-barras": 2,
    "leyenda": {
      "l1": "Dentro Fecha",
      "l2": "Fuera Fecha"
    },
    "colores": {
      "color1": "#579AF1",
      "color2": "#8FBF55"
    },
    "data":
      [
        {
          "label": "Enero",
          "cantidad1": 76.92,
          "cantidad2": 23.08,
        },
        {
          "label": "Febrero",
          "cantidad1": 88.60,
          "cantidad2": 11.40,
        },
        {
          "label": "Marzo",
          "cantidad1": 79.43,
          "cantidad2": 20.57,
        },
      ]
  }

  dataBar4 = {
    "id": 2,
    "titulo": "",
    "cantidad-barras": 2,
    "leyenda": {
      "l1": "Dentro Fecha",
      "l2": "Fuera Fecha"
    },
    "colores": {
      "color1": "#579AF1",
      "color2": "#8FBF55"
    },
    "data":
      [
        {
          "label": "Enero",
          "cantidad1": 76.92,
          "cantidad2": 23.08,
        },
        {
          "label": "Febrero",
          "cantidad1": 88.60,
          "cantidad2": 11.40,
        },
        {
          "label": "Marzo",
          "cantidad1": 79.43,
          "cantidad2": 20.57,
        },
      ]
  }

  dataPie = [
    {
      "titulo": "Enero",
      "data":
        [
          {
            "label": "Dentro Fecha",
            "color": "#579AF1",
            "cantidad": 500,
          },
          {
            "label": "Fuera Fecha",
            "color": "#8FBF55",
            "cantidad": 150
          }
        ],
    },
    {
      "titulo": "Febrero",
      "data":
        [
          {
            "label": "Dentro Fecha",
            "color": "#579AF1",
            "cantidad": 3500,
          },
          {
            "label": "Fuera Fecha",
            "color": "#8FBF55",
            "cantidad": 450
          }
        ],
    },
    {
      "titulo": "Marzo",
      "data":
        [
          {
            "label": "Dentro Fecha",
            "color": "#579AF1",
            "cantidad": 4250,
          },
          {
            "label": "Fuera Fecha",
            "color": "#8FBF55",
            "cantidad": 1100
          }
        ],
    }
  ]

  dataPie2 = [
    {
      "titulo": "Enero",
      "data":
        [
          {
            "label": "Dentro Fecha",
            "color": "#579AF1",
            "cantidad": 500,
          },
          {
            "label": "Fuera Fecha",
            "color": "#8FBF55",
            "cantidad": 150
          }
        ],
    },
    {
      "titulo": "Febrero",
      "data":
        [
          {
            "label": "Dentro Fecha",
            "color": "#579AF1",
            "cantidad": 3500,
          },
          {
            "label": "Fuera Fecha",
            "color": "#8FBF55",
            "cantidad": 450
          }
        ],
    },
    {
      "titulo": "Marzo",
      "data":
        [
          {
            "label": "Dentro Fecha",
            "color": "#579AF1",
            "cantidad": 4250,
          },
          {
            "label": "Fuera Fecha",
            "color": "#8FBF55",
            "cantidad": 1100
          }
        ],
    }
  ]

}

