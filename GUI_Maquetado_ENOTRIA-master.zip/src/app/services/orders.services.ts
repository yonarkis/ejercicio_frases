import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from '../../environments/environment';

import { Deparment } from '../models/deparment.models'
import { Province } from '../models/province.models'
import { District } from '../models/district.models'


@Injectable({
    providedIn: 'root'
})

export class OrderService {
    private basePath = environment.UrlServiceAPIOrders + "v1/order/";
    private paramsPath = environment.UrlServiceAPIOrders + "v1/param/";

    selectedDeparment: Deparment;
    deparment: Deparment[];

    selectedProvince: Province;
    province: Province[];

    selectedDistrict: District;
    district: District[];

    constructor(private http: HttpClient) { }

    register(orden: any): Observable<any> {

        let headers = new HttpHeaders()
            .set('Content-Type', 'application/json');

        return this.http
            .post<any>(
                this.basePath + 'newOrder', orden, { headers: headers }
            )
            .pipe(
                map(res => {
                    return res;
                })
            );
    }


    getDeparment(): Observable<any> {

        let headers = new HttpHeaders()
            .set('Content-Type', 'application/json');

        return this.http
            .get<Deparment[]>(
                this.paramsPath + 'getUbigeo?type=deparment', { headers: headers }
            )
            .pipe(
                map(res => {
                    return res;
                })
            );
    }

    getProvince(id_deparment): Observable<any> {

        let headers = new HttpHeaders()
            .set('Content-Type', 'application/json');

        return this.http
            .get<Province[]>(
                this.paramsPath + 'getUbigeo?type=province&ubigeoContainerId='+id_deparment, { headers: headers }
            )
            .pipe(
                map(res => {
                    return res;
                })
            );
    }

    getDistrict(id_province): Observable<any> {

        let headers = new HttpHeaders()
            .set('Content-Type', 'application/json');

            console.log(id_province)

        return this.http
            .get<District[]>(
                this.paramsPath + 'getUbigeo?type=district&ubigeoContainerId='+id_province, { headers: headers }
            )
            .pipe(
                map(res => {
                    return res;
                })
            );
    }

    getDeparmentDelivery(): Observable<any> {

        let headers = new HttpHeaders()
            .set('Content-Type', 'application/json');

        return this.http
            .get<Deparment[]>(
                this.paramsPath + 'getUbigeo?type=deparment', { headers: headers }
            )
            .pipe(
                map(res => {
                    return res;
                })
            );
    }

    getProvinceDelivery(id_deparment): Observable<any> {

        let headers = new HttpHeaders()
            .set('Content-Type', 'application/json');

        return this.http
            .get<Province[]>(
                this.paramsPath + 'getUbigeo?type=province&ubigeoContainerId='+id_deparment, { headers: headers }
            )
            .pipe(
                map(res => {
                    return res;
                })
            );
    }

    getDistrictDelivery(id_province): Observable<any> {

        let headers = new HttpHeaders()
            .set('Content-Type', 'application/json');

            console.log(id_province)

        return this.http
            .get<District[]>(
                this.paramsPath + 'getUbigeo?type=district&ubigeoContainerId='+id_province, { headers: headers }
            )
            .pipe(
                map(res => {
                    return res;
                })
            );
    }

}

// <ng-template ngbTabContent>
//                                 <div class="orders-office-form">
//                                     <div class="form-row">
//                                         <div class="form-group col-md-3">
//                                             <label class="orders-office-form__label">Tipo de vía</label>
//                                             <select class="form-control" [ngModel]="orden.pickupData.addressDetails.streetType">
//                                                 <option></option>
//                                                 <option value="Avenida">Avenida</option>
//                                                 <option value="Jiron">Jiron</option>
//                                             </select>
//                                         </div>
//                                         <div class="form-group col-md-9">
//                                             <label class="orders-office-form__label">Escribe la dirección</label>
//                                             <input [ngModel]="orden.pickupData.addressDetails.address" type="text" class="form-control office-form"
//                                                 placeholder="Ejem. Av Arenales 5225">
//                                         </div>
//                                     </div>

//                                     <div class="form-row">
//                                         <div class="form-group col-md-6">
//                                             <label class="orders-office-form__label">Departamento</label>
//                                             <select class="form-control" [ngModel]="orden.pickupData.addressDetails.department">
//                                                 <option></option>
//                                                 <option value="Lima">Lima</option>
//                                                 <option value="Arequipa">Arequipa</option>
//                                                 <option value="La Libertad">La Libertad</option>
//                                                 <option value="Piura">Piura</option>
//                                                 <option value="Cajamarca">Cajamarca</option>
//                                                 <option value="Lambayeque">Lambayeque</option>
//                                             </select>
//                                         </div>
//                                         <div class="form-group col-md-6">
//                                             <label class="orders-office-form__label">Provincia</label>
//                                             <select class="form-control" [ngModel]="orden.pickupData.addressDetails.province">
//                                                 <option></option>
//                                                 <option value="Lima">Provincia 1</option>
//                                                 <option value="2">Provincia 2</option>
//                                                 <option value="3">Provincia 3</option>
//                                                 <option value="4">Provincia 4</option>
//                                                 <option value="5">Provincia 5</option>
//                                                 <option value="6">Provincia 6</option>
//                                             </select>
//                                         </div>
//                                     </div>

//                                     <div class="form-row">
//                                         <div class="form-group col-md-4">
//                                             <label class="orders-office-form__label">Distrito</label>
//                                             <select class="form-control" [ngModel]="orden.pickupData.addressDetails.district">
//                                                 <option></option>
//                                                 <option value="1">Distrito 1</option>
//                                                 <option value="2">Distrito 2</option>
//                                                 <option value="3">Distrito 3</option>
//                                                 <option value="4">Distrito 4</option>
//                                                 <option value="5">Distrito 5</option>
//                                                 <option value="6">Distrito 6</option>
//                                             </select>
//                                         </div>
//                                         <div class="form-group col-md-4">
//                                             <label class="orders-office-form__label">Urbanización</label>
//                                             <select class="form-control" [ngModel]="orden.pickupData.addressDetails.urbanization">
//                                                 <option></option>
//                                                 <option value="Urbanización 1">Urbanización 1</option>
//                                                 <option value="Urbanización 2">Urbanización 2</option>
//                                                 <option value="Urbanización 3">Urbanización 3</option>
//                                                 <option value="Urbanización 4">Urbanización 4</option>
//                                                 <option value="Urbanización 5">Urbanización 5</option>
//                                                 <option value="Urbanización 6">Urbanización 6</option>
//                                             </select>
//                                         </div>
//                                         <div class="form-group col-md-4">
//                                             <label class="orders-office-form__label">Tipo de vivienda</label>
//                                             <select class="form-control" [ngModel]="orden.pickupData.addressDetails.housingType">
//                                                 <option></option>
//                                                 <option value="Tipo de vivienda 1">Tipo de vivienda 1</option>
//                                                 <option value="Tipo de vivienda 2">Tipo de vivienda 2</option>
//                                                 <option value="Tipo de vivienda 3">Tipo de vivienda 3</option>
//                                                 <option value="Tipo de vivienda 4">Tipo de vivienda 4</option>
//                                                 <option value="Tipo de vivienda 5">Tipo de vivienda 5</option>
//                                                 <option value="Tipo de vivienda 6">Tipo de vivienda 6</option>
//                                             </select>
//                                         </div>
//                                     </div>

//                                     <div class="form-group">
//                                         <label class="orders-office-form__label">Persona de contacto</label>
//                                         <input type="text" class="form-control office-form"
//                                             placeholder=" Ejem. Pepito Perez" [ngModel]="orden.pickupData.personDetails.fullName">

//                                     </div>

//                                     <div class="form-row">
//                                         <div class="form-group col-md-6">
//                                             <label class="orders-office-form__label">Tipo de identificación</label>
//                                             <select class="form-control" [ngModel]="orden.pickupData.personDetails.documentType">
//                                                 <option></option>
//                                                 <option value="Dni">DNI</option>
//                                                 <option value="Ce">CE</option>
//                                                 <option value="Passport">Pasaporte</option>
//                                             </select>
//                                         </div>
//                                         <div class="form-group col-md-6">
//                                             <label class="orders-office-form__label">Numero de
//                                                 identificación</label>
//                                             <input type="number" class="form-control office-form" [ngModel]="orden.pickupData.personDetails.documentId">
//                                         </div>
//                                     </div>

//                                     <div class="form-group">
//                                         <label class="orders-office-form__label">Teléfono</label>
//                                         <input type="text" class="form-control office-form"
//                                             placeholder="(111) 999 888" [ngModel]="orden.pickupData.personDetails.phoneNumber">
//                                     </div>

//                                     <div class="form-group">
//                                         <label class="orders-office-form__label">Instrucciones</label>
//                                         <textarea class="orders-office-textarea" id="exampleFormControlTextarea1"
//                                             rows="3" [ngModel]="orden.pickupData.addressDetails.instructions"></textarea>
//                                     </div>

//                                 </div>
//                             </ng-template>