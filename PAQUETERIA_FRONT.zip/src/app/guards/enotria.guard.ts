// import { Injectable } from '@angular/core';
// import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree } from '@angular/router';
// import { Observable } from 'rxjs';
// import { StorageService } from '../services/auth/storage.service';
// //import { Location } from '@angular/common';


// @Injectable()
// export class EnotriaUserGuard implements CanActivate {

//   redirectionURLs: string[] = [ '/courier/avance-courier/avance', '/distribucion/plantillas/crear' ];
//   constructor(
//     private router: Router,
// 		private storageService: StorageService,
// 		//private location: Location
//   ) { }

//   canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot):
//   Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree
//   {
//     const type = route.data.type;
//     if (this.storageService.getCurrentSession().userType === type) {
//       return true;
//     }
//     let redirectionURL: string;
//     if(this.redirectionURLs[type]) {
//       redirectionURL = this.redirectionURLs[type];
//     }
//     else {
//       redirectionURL = '/login';
//     }
//     this.router.navigate([ redirectionURL ]);
//     return false;
// 	}
// }
