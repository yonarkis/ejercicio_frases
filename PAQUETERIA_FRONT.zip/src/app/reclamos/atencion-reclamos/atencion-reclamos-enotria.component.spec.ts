import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AtencionReclamosEnotriaComponent } from './atencion-reclamos-enotria.component';

describe('AtencionReclamosEnotriaComponent', () => {
  let component: AtencionReclamosEnotriaComponent;
  let fixture: ComponentFixture<AtencionReclamosEnotriaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AtencionReclamosEnotriaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AtencionReclamosEnotriaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
