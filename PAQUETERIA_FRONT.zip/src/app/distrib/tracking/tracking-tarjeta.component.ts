import { Component, OnInit, Input } from '@angular/core';
import {NgbModal, ModalDismissReasons, NgbModalOptions} from '@ng-bootstrap/ng-bootstrap';
import {NgbCalendar, NgbDateStruct} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-tracking-tarjeta',
  templateUrl: './tracking-tarjeta.component.html',
  styleUrls: ['./tracking-tarjeta.component.scss']
})
export class TrackingTarjetaComponent implements OnInit {

  @Input() col1="#91BC53"
  @Input() ava1=100

  @Input() col2="#F8B350"
  @Input() ava2=30

  @Input() tabSel:number = 2
  clickTab(n:number){
    this.tabSel = n
  }
  
  constructor() { }
  


  ngOnInit() {
  }

}
