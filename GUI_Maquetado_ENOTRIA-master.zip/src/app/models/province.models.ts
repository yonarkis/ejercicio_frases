export class Province {
    constructor(id = "", name = "", department_id = "") {
      this.id = id;
      this.name = name;
      this.department_id = department_id;
    }
  
    id: string;
    name: string;
    department_id: string;
  }
  