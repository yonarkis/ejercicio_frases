import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-pie-avance-fecha',
  templateUrl: './pie-avance-fecha.component.html',
  styleUrls: ['./pie-avance-fecha.component.scss']
})
export class PieAvanceFechaComponent implements OnInit {

  @Input() avance:number = 25
  @Input() label:string = "Antesdeayer"
  @Input() color:string = "#ce4b99"
  @Input() backColor:string = "#eee"
  @Input() background:string = "#fff"
  avance2 = 75
  complemento = 75
  avanceBind:string = "25 75"
  xxx = false
  constructor() { }

  ngOnInit() {
    this.setData()
    // console.log(this.setData())
    
  }
  setData(){
    if (this.avance >= 0 && this.avance <= 100) {
      this.complemento = 100-this.avance
      console.log("1")
    } else {
      this.avance = 0
      this.complemento = 100
      this.label = "error data"
      console.log("2")
    }
    this.avanceBind = String(this.avance + " " + this.complemento)
    console.log(this.avanceBind)
    this.xxx = true
    // return String(this.avance + " " + this.complemento)
  }

}