import { Component, OnInit, Input } from '@angular/core';
import { Chart } from 'chart.js';

@Component({
  selector: 'app-line-chart',
  templateUrl: './line-chart.component.html',
  styleUrls: ['./line-chart.component.scss']
})
export class LineChartComponent implements OnInit {

  myLineChart: any = 1;
  titulo: string;
  leyenda: any = [];
  labels: any = [];
  colores: any = [];
  @Input() data: any;
  dataFinal = [];
  x = [];

  constructor() { }

  ngOnInit() {

    this.titulo = this.data["titulo"];
    var tienda = this.data["data"];

    for (let i = 0; i < this.data["cantidad-barras"]; i++) {
      this.leyenda.push(this.data["leyenda"]["l" + (i + 1)]);
      this.colores.push(this.data["colores"]["color" + (i + 1)]);

      var miarr = new Array;
      this.x.push(i);

      for (let index = 0; index < this.data["data"].length; index++) {
        this.labels[index] = this.data["data"][index]["label"];
        miarr.push(tienda[index]["cantidad" + (i + 1)])

      }
      this.x[i] = miarr;
      this.dataFinal.push(
        {
          label: this.leyenda[i],
          fill: false,
          data: this.x[i],
          backgroundColor: this.colores[i],
        }
      )
    }

  }


  ngAfterViewInit() {

    var options = {
      animation: {
        duration: 1,
        onComplete: function () {
          var chartInstance = this.chart,
            ctx = chartInstance.ctx;
          ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontSize, Chart.defaults.global.defaultFontStyle, Chart.defaults.global.defaultFontFamily);
          ctx.textAlign = 'center';
          ctx.textBaseline = 'bottom';

          this.data.datasets.forEach(function (dataset, i) {
            var meta = chartInstance.controller.getDatasetMeta(i);
            meta.data.forEach(function (bar, index) {
              var data = dataset.data[index];
              ctx.fillText(data, bar._model.x, bar._model.y - 5);
            });
          });
        }
      },
      elements: {
        line: {
          tension: 0,
        }
      },
      responsive: true,
      maintainAspectRatio: false,
      title: {
        display: true,
        text: this.titulo
      },
      legend: {
        display: true,
        position: 'bottom',
      },
      scales: {
        xAxes: [{
          stacked: false,
          gridLines: {
            display: true
          },
          ticks: {
            display: true //this will remove only the label
          }
        }],
        yAxes: [{
          ticks: {
            beginAtZero: true
          },
          gridLines: {
            display: false,
          },
        }]
      }
    };

    this.myLineChart = new Chart('line' + this.data["id"], {
      type: 'line',
      data: {
        labels: this.labels,
        datasets: this.dataFinal,
      },
      options: options
    });
  }

}
