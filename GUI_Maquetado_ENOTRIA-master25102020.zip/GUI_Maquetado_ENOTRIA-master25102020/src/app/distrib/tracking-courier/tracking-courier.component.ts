import { Component, OnInit } from '@angular/core';
import { NgbModal, ModalDismissReasons, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-tracking-courier',
  templateUrl: './tracking-courier.component.html',
  styleUrls: ['./tracking-courier.component.scss']
})
export class TrackingCourierComponent implements OnInit {


  constructor(public modalService: NgbModal) { }

  ngOnInit() {
  }

  ids = [1, 2, 3, 4, 5, 6]

  dataPie = [
    {
      "titulo": "Nombre del Courier | 6161 Unidades",
      "data":
        [
          {
            "label": "Entrega",
            "color": "#579AF1",
            "cantidad": 4079,
          },
          {
            "label": "Motivo",
            "color": "#F2A73D",
            "cantidad": 882
          },
          {
            "label": "Pendiente",
            "color": "#8FBF55",
            "cantidad": 1000
          },
          {
            "label": "Lorem",
            "color": "#EA403C",
            "cantidad": 200
          }
        ],
    }
  ]

}
