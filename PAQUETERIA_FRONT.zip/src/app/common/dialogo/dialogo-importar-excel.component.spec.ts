import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DialogoImportarExcelComponent } from './dialogo-importar-excel.component';

describe('DialogoImportarExcelComponent', () => {
  let component: DialogoImportarExcelComponent;
  let fixture: ComponentFixture<DialogoImportarExcelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DialogoImportarExcelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DialogoImportarExcelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
