import { Component, OnInit } from '@angular/core';
import { NgbModal, ModalDismissReasons, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-crear-nueva',
  templateUrl: './crear-nueva.component.html',
  styleUrls: ['./crear-nueva.component.scss']
})
export class CrearNuevaComponent implements OnInit {

  semanaDias1 = [false, false, false, false, false, false, false]
  semanaDias2 = [false, false, false, false, false, false, false]
  semanaDias3 = [false, false, false, false, false, false, false]
  semanaDias4 = [false, false, false, false, false, false, false]
  clickSemana1(n) { this.semanaDias1[n] = !this.semanaDias1[n] }
  clickSemana2(n) { this.semanaDias2[n] = !this.semanaDias2[n] }
  clickSemana3(n) { this.semanaDias3[n] = !this.semanaDias3[n] }
  clickSemana4(n) { this.semanaDias4[n] = !this.semanaDias4[n] }

  constructor(public modalService: NgbModal) { }

  step = 0;
  closeResult: string;
  modalOption: NgbModalOptions = {};
  ngOnInit() {
  }
  steps(n: number) {
    this.step = n
  }

  /* Popup */
  openModalSmall(contenido) {
    this.modalOption.backdrop = 'static';
    this.modalOption.keyboard = false;
    this.modalService.open(contenido, this.modalOption).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  openModalLarge(contenido) {
    this.modalOption.backdrop = 'static';
    this.modalOption.keyboard = false;
    this.modalOption.windowClass = 'xlModal'
    this.modalService.open(contenido, this.modalOption).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  } 
  
  open(content) {
    this.modalService.open(content);
  }
}
