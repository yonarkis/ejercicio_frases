import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DialogoRelacionarComponent } from './dialogo-relacionar.component';

describe('DialogoRelacionarComponent', () => {
  let component: DialogoRelacionarComponent;
  let fixture: ComponentFixture<DialogoRelacionarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DialogoRelacionarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DialogoRelacionarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
