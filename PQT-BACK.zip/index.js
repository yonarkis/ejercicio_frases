'use strict';

const bootstrap = require('./lib/infrastructure/config/bootstrap');
const initServer = require('./lib/infrastructure/webserver/server-express');
const chalk = require('chalk');

// Errores no capturados de la aplicación
process.on('uncaughtException', (error) => {
  console.error(`uncaughtException: ${error.stack}`);
  console.error(chalk.bold.red('EXCEPCIÓN NO CAPTURADA'));
  console.error(chalk.bold.red('TERMINANDO PROCESO'));
  console.error(error);
  process.exit();
});

process.on("unhandledRejection", (reason, promise) => {
  console.error(`unhandledRejection: ${reason.stack}`);
  console.log(chalk.bold.red('PROMESA NO CAPTURADA'));
});

// Start the server
const start = async () => {

  try {
    const appContext = await bootstrap.init();
    const server = await initServer(appContext);
  } catch (err) {
    console.log(err);
    process.exit(1);
  }
};

start();