export class Login {

  public usuario: string;
  public contrasenia: string;

  // constructor(
	// 	public usuario: string,
	// 	public contrasenia: string
	// ){}


  constructor(object: any) {
    this.usuario = object.usuario ? object.usuario : null;
    this.contrasenia = object.contrasenia ? object.contrasenia : null;
  }
}
