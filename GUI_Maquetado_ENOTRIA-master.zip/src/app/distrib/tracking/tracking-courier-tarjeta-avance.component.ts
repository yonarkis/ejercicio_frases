import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-tracking-courier-tarjeta-avance',
  templateUrl: './tracking-courier-tarjeta-avance.component.html',
  styleUrls: ['./tracking-courier-tarjeta-avance.component.scss']
})
export class TrackingCourierTarjetaAvanceComponent implements OnInit {

  @Input() avance:number = 100
  @Input() color:string = "#ce4b99"
  @Input() backColor:string = "#eee"

  avance2 = 75
  complemento = 75
  avanceBind:string = "25 75"
  xxx = false
  constructor() { }

  ngOnInit() {
    this.setData()
    // console.log(this.setData())
    
  }
  setData(){
    if (this.avance >= 0 && this.avance <= 100) {
      this.complemento = 100-this.avance
      console.log("1")
    } else {
      this.avance = 0
      this.complemento = 100
      console.log("2")
    }
    this.avanceBind = String(this.avance + " " + this.complemento)
    console.log(this.avanceBind)
    this.xxx = true
    // return String(this.avance + " " + this.complemento)
  }

}