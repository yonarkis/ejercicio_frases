import { Component, OnInit, Input} from '@angular/core';
import { NgbModal, ModalDismissReasons, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-imprimir-pedido',
  templateUrl: './imprimir-pedido.component.html',
  styleUrls: ['./imprimir-pedido.component.scss']
})
export class ImprimirPedidoComponent implements OnInit {

  constructor(public modalService: NgbModal) { }

  semanaDias1 = [false, false, false, false, false, false, false]
  semanaDias2 = [false, false, false, false, false, false, false]
  semanaDias3 = [false, false, false, false, false, false, false]
  semanaDias4 = [false, false, false, false, false, false, false]
  clickSemana1(n) { this.semanaDias1[n] = !this.semanaDias1[n] }
  clickSemana2(n) { this.semanaDias2[n] = !this.semanaDias2[n] }
  clickSemana3(n) { this.semanaDias3[n] = !this.semanaDias3[n] }
  clickSemana4(n) { this.semanaDias4[n] = !this.semanaDias4[n] }

  /* Popup */
  modalOption: NgbModalOptions = {};
  closeResult: string;

  // console.log(idPedido)
  /* Popup */
  openModalSmall(contenido) {
    this.modalOption.backdrop = 'static';
    this.modalOption.keyboard = false;
    this.modalService.open(contenido, this.modalOption).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  hideModal() {
    this.modalService.dismissAll();
  }



  openModalMedium(contenido) {
    this.modalOption.backdrop = 'static';
    this.modalOption.keyboard = false;
    this.modalOption.windowClass = 'mediumModal'
    this.modalService.open(contenido, this.modalOption).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  openModalLarge(contenido) {
    this.modalOption.backdrop = 'static';
    this.modalOption.keyboard = false;
    this.modalOption.windowClass = 'xlModal'
    this.modalService.open(contenido, this.modalOption).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

// elementos barcode

@Input() idPedido:string = "Antesdeayer"



elementType = 'svg';
value = this.idPedido;
format = 'CODE128';
lineColor = '#000000';
width = 2;
height = 100;
displayValue = true;
fontOptions = '';
font = 'monospace';
textAlign = 'center';
textPosition = 'bottom';
textMargin = 2;
fontSize = 20;
background = '#ffffff';
margin = 10;
marginTop = 10;
marginBottom = 10;
marginLeft = 10;
marginRight = 10;

get values(): string[] {
  return this.value.split('\n');
}

codeList: string[] = [
  '', 'CODE128',
  'CODE128A', 'CODE128B', 'CODE128C',
  'UPC', 'EAN8', 'EAN5', 'EAN2',
  'CODE39',
  'ITF14',
  'MSI', 'MSI10', 'MSI11', 'MSI1010', 'MSI1110',
  'pharmacode',
  'codabar'
];



  step = 0
  ngOnInit() {
  }
  steps(n: number) {
    this.step = n
  }

  open(content) {
    this.modalService.open(content);
  }
}
