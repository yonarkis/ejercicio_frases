import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DialogoAgregarColumnasComponent } from './dialogo-agregar-columnas.component';

describe('DialogoAgregarColumnasComponent', () => {
  let component: DialogoAgregarColumnasComponent;
  let fixture: ComponentFixture<DialogoAgregarColumnasComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DialogoAgregarColumnasComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DialogoAgregarColumnasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
