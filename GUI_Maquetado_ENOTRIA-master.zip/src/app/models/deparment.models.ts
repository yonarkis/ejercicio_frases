export class Deparment {
    constructor(id = "", name = "") {
      this.id = id;
      this.name = name;
    }
  
    id: string;
    name: string;
  }
  