import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './common/login/login.component';
import { OriginComponent } from './common/origin/origin.component';
import { DemoComponent } from './distrib/demo1/demo.component';
import { CreacionComponent } from './distrib/plantillas/creacion.component';
import { CrearDetalleComponent } from './distrib/plantillas/crear-detalle.component';
import { AsignacionComponent } from './distrib/plantillas/asignacion.component';
import { AsignarDetalleComponent } from './distrib/plantillas/asignar-detalle.component';
import { CourierComponent } from './courier/courier.component';
import { CourierAvanceComponent } from './courier/avance/courier-avance.component';
import { CourierDetalleComponent } from './courier/courier-detalle.component';
import { CourierLogComponent } from './courier/avance/courier-log.component';
import { CourierAvanceDetalleComponent } from './courier/avance/courier-avance-detalle.component';
import { CourierLogDetalleComponent } from './courier/avance/courier-log-detalle.component';
import { EfectividadComponent } from './distrib/dashboard/efectividad/efectividad.component';
import { InconsistenciaComponent } from './distrib/dashboard/inconsistencia/inconsistencia.component';
import { EficienciaComponent } from './distrib/dashboard/eficiencia/eficiencia.component';
import { AtencionReclamosComponent } from './reclamos/atencion-reclamos/atencion-reclamos.component';
import { AtencionReclamosEnotriaComponent } from './reclamos/atencion-reclamos/atencion-reclamos-enotria.component';
import { DesignTablaComponent } from './reportes/design-tabla/design-tabla.component';
import { TrackingOrdersComponent } from './tracking-orders/tracking-orders.component';

// PROYECTO PAQUETERIA

import { PedidosComponent } from './pedidos/pedidos.component';
import { NewOrdersComponent } from './nuevo-pedido/new-orders.component';


const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  // { path: '', redirectTo: 'distribucion/demo', pathMatch: 'full' },
  { path: '', component: OriginComponent, children: [

      // PAQUETERIA
      
      // { path: 'pedidos', component: PedidosComponent },
      { path: 'tracking-pedido', component: TrackingOrdersComponent },
      { path: 'nuevo-pedido', component: NewOrdersComponent },

      // EDI
      { path: 'distribucion/demo', component: DemoComponent },
      { path: 'distribucion/plantillas/crear', component: CreacionComponent},
      { path: 'distribucion/plantillas/crear/detalle', component: CrearDetalleComponent},
      { path: 'distribucion/plantillas/asignar', component: AsignacionComponent},
      { path: 'distribucion/plantillas/asignar/detalle', component: AsignarDetalleComponent},
      { path: 'distribucion/plantillas', redirectTo: 'distribucion/plantillas/crear', pathMatch: 'full' },

      { path: 'distribucion/dashboard/efectividad', component: EfectividadComponent},
      { path: 'distribucion/dashboard/inconsistencias', component: InconsistenciaComponent},
      { path: 'distribucion/dashboard/eficiencia', component: EficienciaComponent},
      { path: 'distribucion/tabla-design', component: DesignTablaComponent },
      { path: 'distribucion/dashboard', redirectTo: 'distribucion/dashboard/efectividad', pathMatch: 'full' },


     /*  { path: 'courier/avance-enotria/', component: CourierComponent }, */
      { path: 'courier/avance-enotria/avance', component: CourierComponent },
      { path: 'courier/avance-enotria/avance/detalle', component: CourierDetalleComponent },
      { path: 'courier/avance-enotria', redirectTo: 'courier/avance-enotria/avance', pathMatch: 'full' },
      
      { path: 'courier/avance-courier/avance', component: CourierAvanceComponent },
      { path: 'courier/avance-courier/avance/detalle', component: CourierAvanceDetalleComponent },
      { path: 'courier/avance-courier/log', component: CourierLogComponent },
      { path: 'courier/avance-courier/log/detalle', component: CourierLogDetalleComponent },
      { path: 'courier/avance-courier', redirectTo: 'courier/avance-courier', pathMatch: 'full' },

      { path: 'reclamos/atencion-reclamos', component: AtencionReclamosComponent },
      { path: 'reclamos/atencion-reclamos-enotria', component: AtencionReclamosEnotriaComponent },

      

      
    ]
  },
  { path: '**', redirectTo: 'distribucion/plantillas/crear', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
