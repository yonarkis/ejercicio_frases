import { Component, OnInit } from '@angular/core';
import {NgbModal, ModalDismissReasons, NgbModalOptions} from '@ng-bootstrap/ng-bootstrap';
import {NgbCalendar, NgbDateStruct, NgbProgressbar} from '@ng-bootstrap/ng-bootstrap';
import { Router, ActivatedRoute, Params} from '@angular/router';

@Component({
  selector: 'app-demo',
  templateUrl: './demo.component.html',
  styleUrls: ['./demo.component.scss']
})
export class DemoComponent implements OnInit {

  // VARIABLES DIALOGOS
  titulo = "Duplicar Registro"
  cuerpo = "Se generará un duplicado del registro"
  // success = 1 ; warning = 2 ; error = 3
  dialogoTipo = 1


  model: NgbDateStruct;
  model2: NgbDateStruct;


  constructor(private modalService: NgbModal,private calendar: NgbCalendar,private router: Router) { }

  controlOver = [false, false, false, false, false, false, false,]
  clickControlOver(n:number){
    var el = this.controlOver[n];
    el = !el
    // this.controlOver[n] = !this.controlOver[n]
  }


  // Selección múltiple
  selectall = false
  selectToggle(){
    this.selectall = !this.selectall
  }
  // FILTRO
  filtroHidden = true
  filtroToggle(){
    this.filtroHidden = !this.filtroHidden
  }


  /* POPUPS  */
  closeResult: string;
  modalOptionSmall: NgbModalOptions = {};
  modalOption: NgbModalOptions = {};

  openModalSmall(contenido) {
    this.modalOptionSmall.backdrop = 'static';
    this.modalOptionSmall.keyboard = false;
    this.modalService.open(contenido, this.modalOptionSmall).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  openModalLarge(contenido) {
    this.modalOption.backdrop = 'static';
    this.modalOption.keyboard = false;
    this.modalOption.windowClass = 'xlModal'
    this.modalService.open(contenido, this.modalOption).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  } open(content) {
    this.modalService.open(content);
  }

  /* FIN POPUPS  */

  ngOnInit() {
  }

}
