import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ToolbarChartComponent } from './toolbar-chart.component';

describe('ToolbarChartComponent', () => {
  let component: ToolbarChartComponent;
  let fixture: ComponentFixture<ToolbarChartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ToolbarChartComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ToolbarChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
