import { Component, OnInit } from '@angular/core';
import {NgbModal, ModalDismissReasons, NgbModalOptions} from '@ng-bootstrap/ng-bootstrap';
import {NgbCalendar, NgbDateStruct, NgbProgressbar} from '@ng-bootstrap/ng-bootstrap';
import { Router, ActivatedRoute, Params} from '@angular/router';



// @Component({
//   selector: 'ngbd-nav-basic',
//   templateUrl: './nav-basic.html'
// })

@Component({
  selector: 'app-demo',
  templateUrl: './new-orders.component.html',
  styleUrls: ['./new-orders.component.scss']
})
export class NewOrdersComponent implements OnInit {

  // VARIABLES DIALOGOS
  titulo = "Duplicar Registro"
  cuerpo = "Se generará un duplicado del registro"
  // success = 1 ; warning = 2 ; error = 3
  dialogoTipo = 1


  model: NgbDateStruct;
  model2: NgbDateStruct;

  isShownDropdown : boolean = false; // hidden by default

  isShownShippingType : boolean = false; // hidden by default

  isShownDivWidespread : boolean = false; // hidden by default

  isShownDivImgClient : boolean = true; 
  isHideDivImgClient : boolean = false;
  
  isShownDivImgInternal : boolean = true; 
  isHideDivImgInternal : boolean = false;

  addClassClient: boolean = true;
  addClassInternal: boolean = true;

  // opciones de tipo de envio
  
  addClassSendOrdersLima: boolean = true;
  addClassSendOrdersProvince: boolean = true;
  addClassSendOrdersInt: boolean = true;

  isShownDivImgLima : boolean = true; 
  isHideDivImgLima : boolean = false;

  isShownDivImgProvince : boolean = true; 
  isHideDivImgProvince : boolean = false;

  isShownDivImgInt : boolean = true; 
  isHideDivImgInt : boolean = false;

// opciones de paqueteria

  addClassDocument: boolean = true;
  addClassPackage: boolean = true;
  addClassValued: boolean = true;

  isShownDivImgDocument : boolean = true; 
  isHideDivImgDocument : boolean = false;

  isShownDivImgPackage : boolean = true; 
  isHideDivImgPackage : boolean = false;

  isShownDivImgValued : boolean = true; 
  isHideDivImgValued : boolean = false;

  showSendOrders(index){
    this.isShownDropdown = true;
    if(index === 1){
      
      this.addClassClient = false;
      this.addClassInternal = true;
      
      this.isShownDivImgClient = false
      this.isHideDivImgClient = true ; 

      this.isShownDivImgInternal = true
      this.isHideDivImgInternal = false ; 

    }
    if(index === 2){

      this.addClassClient = true;
      this.addClassInternal = false;

      this.isShownDivImgClient = true;
      this.isHideDivImgClient = false;

      this.isShownDivImgInternal = false;
      this.isHideDivImgInternal = true;
    }
  }

  showSendDivWidespread(index){
    this.isShownDivWidespread = true;

    if(index === 1){
      this.addClassSendOrdersLima = false
      this.addClassSendOrdersProvince = true
      this.addClassSendOrdersInt = true

      this.isShownDivImgLima = false;
      this.isHideDivImgLima = true; 

      this.isShownDivImgProvince = true;
      this.isHideDivImgProvince = false; 

      this.isShownDivImgInt = true;
      this.isHideDivImgInt = false; 
    }

    if(index === 2){
      this.addClassSendOrdersLima = true
      this.addClassSendOrdersProvince = false
      this.addClassSendOrdersInt = true

      this.isShownDivImgLima = true;
      this.isHideDivImgLima = false;

      this.isShownDivImgProvince = false;
      this.isHideDivImgProvince = true;

      this.isShownDivImgInt = true;
      this.isHideDivImgInt = false;
    }

    if(index === 3){
      this.addClassSendOrdersLima = true
      this.addClassSendOrdersProvince = true
      this.addClassSendOrdersInt = false

      this.isShownDivImgLima = true;
      this.isHideDivImgLima = false;

      this.isShownDivImgProvince = true;
      this.isHideDivImgProvince = false; 

      this.isShownDivImgInt = false;
      this.isHideDivImgInt = true;
    }

  }

  showSendPackage(index){
    if(index === 1){
      this.addClassDocument = false
      this.addClassPackage = true
      this.addClassValued = true

      this.isShownDivImgDocument = false;
      this.isHideDivImgDocument = true; 

      this.isShownDivImgPackage = true;
      this.isHideDivImgPackage = false; 

      this.isShownDivImgValued = true;
      this.isHideDivImgValued = false; 
    }

    if(index === 2){
      this.addClassDocument = true
      this.addClassPackage = false
      this.addClassValued = true

      this.isShownDivImgDocument = true;
      this.isHideDivImgDocument = false;

      this.isShownDivImgPackage = false;
      this.isHideDivImgPackage = true;

      this.isShownDivImgValued = true;
      this.isHideDivImgValued = false;
    }

    if(index === 3){
      this.addClassDocument = true
      this.addClassPackage = true
      this.addClassValued = false

      this.isShownDivImgDocument = true;
      this.isHideDivImgDocument = false;

      this.isShownDivImgPackage = true;
      this.isHideDivImgPackage = false; 

      this.isShownDivImgValued = false;
      this.isHideDivImgValued = true;
    }

  }

  changeDropdownProduct(){
    this.isShownShippingType = true;
  }

  // lado : number
  // calculo(){
  //   console.log(lado)
  // }
//   active() {
//     console.log(this);
//     this.isShown = true;
//   }

//   id: 3

//   addClass(id: any) {
//     this.id = id;
// }

//   active2() {
//     console.log(this);
//     this.isShown = false;
//   }


// toggleShow(divshow) {
//   console.log(divshow);
//   this.isShown = ! this.isShown;
// }

// texto: string =  "SI";
// estadoPositivo: boolean = true;

// cambiaEstado() {
//   this.texto = (this.estadoPositivo) ?  "NO" : "SI";
//   this.estadoPositivo = !this.estadoPositivo; 
// }

  constructor(private modalService: NgbModal,private calendar: NgbCalendar,private router: Router) { }

  controlOver = [false, false, false, false, false, false, false,]
  clickControlOver(n:number){
    var el = this.controlOver[n];
    el = !el
    // this.controlOver[n] = !this.controlOver[n]
  }


  // Selección múltiple
  selectall = false
  selectToggle(){
    this.selectall = !this.selectall
  }
  // FILTRO
  filtroHidden = true
  filtroToggle(){
    this.filtroHidden = !this.filtroHidden
  }


  /* POPUPS  */
  closeResult: string;
  modalOptionSmall: NgbModalOptions = {};
  modalOption: NgbModalOptions = {};

  openModalSmall(contenido) {
    this.modalOptionSmall.backdrop = 'static';
    this.modalOptionSmall.keyboard = false;
    this.modalService.open(contenido, this.modalOptionSmall).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  openModalLarge(contenido) {
    this.modalOption.backdrop = 'static';
    this.modalOption.keyboard = false;
    this.modalOption.windowClass = 'xlModal'
    this.modalService.open(contenido, this.modalOption).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  } open(content) {
    this.modalService.open(content);
  }

  /* FIN POPUPS  */

  ngOnInit() {
  }

}

export class NgbdNavBasic {
  active = 1;
}
