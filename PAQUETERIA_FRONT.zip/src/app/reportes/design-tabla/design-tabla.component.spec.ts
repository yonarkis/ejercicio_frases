import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DesignTablaComponent } from './design-tabla.component';

describe('DesignTablaComponent', () => {
  let component: DesignTablaComponent;
  let fixture: ComponentFixture<DesignTablaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DesignTablaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DesignTablaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
