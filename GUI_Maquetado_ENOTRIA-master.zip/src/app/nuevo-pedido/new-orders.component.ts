import { Component, OnInit } from '@angular/core';
import {NgbModal, ModalDismissReasons, NgbModalOptions} from '@ng-bootstrap/ng-bootstrap';
import {NgbCalendar, NgbDateStruct, NgbProgressbar} from '@ng-bootstrap/ng-bootstrap';
import { Router, ActivatedRoute, Params} from '@angular/router';
import { OrderService } from '../services/orders.services'
import { from } from 'rxjs';
import { NgForm } from "@angular/forms";
import { analyzeFileForInjectables } from '@angular/compiler';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';


type order = {
    "customerType": String,
    "shipmentType": String,
    "epicorProduct" : String,
    "pickupType": String, 
    "pickupData": {
        "personDetails": {
            "fullName": String,
            "documentType": String,
            "documentId": String,
            "phoneNumber": String,
            "personId": String
        },
        "addressDetails": {
          "department": String,
          "province": String,
          "district": String,
          "urbanization": String,
          "housingType": String,
          "routeType": String,
          "address": String,
          "instructions": String,
          "officeArea": String,
          "officeId": String
        }
    },
    "deliveryType": String,
    "deliveryData": {
        "personDetails": {
            "fullName": String,
            "documentType": String,
            "documentId": String,
            "phoneNumber": String,
            "personId": String
        },
        "addressDetails": {
            "department": String,
            "province": String,
            "district": String,
            "urbanization": String,
            "housingType": String,
            "routeType": String,
            "address": String,
            "instructions": String,
            "officeArea": String,
            "officeId": String
        }
    },
    "packageType": String,
    "packageData": {
        "long": {
            "unit": String,
            "value": Number
        },
        "width": {
            "unit": String,
            "value": Number
        },
        "height": {
            "unit": String,
            "value": Number
        },
        "weight": {
            "unit": String,
            "value": Number
        },
        "aproxVolume": {
            "unit": String,
            "value": Number
        },
        "description": String
    },
    "isExpress": Boolean,
    "programmedDate": Date
};

// @Component({
//   selector: 'ngbd-nav-basic',
//   templateUrl: './nav-basic.html'
// })

@Component({
  selector: 'app-demo',
  templateUrl: './new-orders.component.html',
  styleUrls: ['./new-orders.component.scss'],
  providers: [OrderService]

})
export class NewOrdersComponent implements OnInit {

  constructor( private orderService: OrderService ) { }
  // constructor(  ) { }
  ngOnInit() {
    this.getDeparment(); this.getDeparmentDelivey(); this.getRouteType(); this.getDocumentType(); this.getHousingType();
  }


  isShownOrdersForms : boolean = false;

  isShownOrdersEmpty: boolean = true;

  isShownOrdersConfirm: boolean = false;

  isShownDropdown : boolean = false; // hidden by default

  isShownShippingType : boolean = false; // hidden by default

  isShownDivWidespread : boolean = false; // hidden by default

  isShownDivImgClient : boolean = true;
  isHideDivImgClient : boolean = false;

  isShownDivImgInternal : boolean = true;
  isHideDivImgInternal : boolean = false;

  addClassClient: boolean = true;
  addClassInternal: boolean = true;

  // opciones de tipo de envio

  addClassSendOrdersLima: boolean = true;
  addClassSendOrdersProvince: boolean = true;
  addClassSendOrdersInt: boolean = true;

  isShownDivImgLima : boolean = true;
  isHideDivImgLima : boolean = false;

  isShownDivImgProvince : boolean = true;
  isHideDivImgProvince : boolean = false;

  isShownDivImgInt : boolean = true;
  isHideDivImgInt : boolean = false;

// opciones de paqueteria

  addClassDocument: boolean = true;
  addClassPackage: boolean = true;
  addClassValued: boolean = true;

  isShownDivImgDocument : boolean = true;
  isHideDivImgDocument : boolean = false;

  isShownDivImgPackage : boolean = true;
  isHideDivImgPackage : boolean = false;

  isShownDivImgValued : boolean = true;
  isHideDivImgValued : boolean = false;

// opciones tipo paquete

  disabledElementDocumentPackage : boolean = false;


  ShownOrdersForms(){
    this.isShownOrdersForms = true;
    this.isShownOrdersEmpty = false;
    this.isShownOrdersConfirm = false;
  }

  OrdersConfirm(){
    this.isShownOrdersConfirm = true;
    this.isShownOrdersForms = false;
  }

  editOrders(){
    this.isShownOrdersForms = true;
    this.isShownOrdersConfirm = false;
  }

  showSendOrders(index){
    this.isShownDropdown = true;
    if(index === 1){

      this.addClassClient = false;
      this.addClassInternal = true;

      this.isShownDivImgClient = false
      this.isHideDivImgClient = true ;

      this.isShownDivImgInternal = true
      this.isHideDivImgInternal = false ;

    }
    if(index === 2){

      this.addClassClient = true;
      this.addClassInternal = false;

      this.isShownDivImgClient = true;
      this.isHideDivImgClient = false;

      this.isShownDivImgInternal = false;
      this.isHideDivImgInternal = true;
    }
  }

  showSendDivWidespread(index){
    this.isShownDivWidespread = true;

    if(index === 1){
      this.addClassSendOrdersLima = false
      this.addClassSendOrdersProvince = true
      this.addClassSendOrdersInt = true

      this.isShownDivImgLima = false;
      this.isHideDivImgLima = true;

      this.isShownDivImgProvince = true;
      this.isHideDivImgProvince = false;

      this.isShownDivImgInt = true;
      this.isHideDivImgInt = false;

    }

    if(index === 2){
      this.addClassSendOrdersLima = true
      this.addClassSendOrdersProvince = false
      this.addClassSendOrdersInt = true

      this.isShownDivImgLima = true;
      this.isHideDivImgLima = false;

      this.isShownDivImgProvince = false;
      this.isHideDivImgProvince = true;

      this.isShownDivImgInt = true;
      this.isHideDivImgInt = false;

    }

    if(index === 3){
      this.addClassSendOrdersLima = true
      this.addClassSendOrdersProvince = true
      this.addClassSendOrdersInt = false

      this.isShownDivImgLima = true;
      this.isHideDivImgLima = false;

      this.isShownDivImgProvince = true;
      this.isHideDivImgProvince = false;

      this.isShownDivImgInt = false;
      this.isHideDivImgInt = true;
    }

  }

  showSendPackage(index){
    if(index === 1){
      this.addClassDocument = false
      this.addClassPackage = true
      this.addClassValued = true

      this.isShownDivImgDocument = false;
      this.isHideDivImgDocument = true;

      this.isShownDivImgPackage = true;
      this.isHideDivImgPackage = false;

      this.isShownDivImgValued = true;
      this.isHideDivImgValued = false;

      this.disabledElementDocumentPackage = true;
    }

    if(index === 2){
      this.addClassDocument = true
      this.addClassPackage = false
      this.addClassValued = true

      this.isShownDivImgDocument = true;
      this.isHideDivImgDocument = false;

      this.isShownDivImgPackage = false;
      this.isHideDivImgPackage = true;

      this.isShownDivImgValued = true;
      this.isHideDivImgValued = false;

      this.disabledElementDocumentPackage = false;
    }

    if(index === 3){
      this.addClassDocument = true
      this.addClassPackage = true
      this.addClassValued = false

      this.isShownDivImgDocument = true;
      this.isHideDivImgDocument = false;

      this.isShownDivImgPackage = true;
      this.isHideDivImgPackage = false;

      this.isShownDivImgValued = false;
      this.isHideDivImgValued = true;

      this.disabledElementDocumentPackage = false;
    }

  }

  changeDropdownProduct(){
    this.isShownShippingType = true;
  }

  assignValue(key, value) {
    this.orden[key] = value;
  }

  ubigeoDeparment = []
  ubigeoProvince = []
  ubigeoDistrict = []

  ubigeoDeparmentDelivery = []
  ubigeoProvinceDelivery = []
  ubigeoDistrictDelivery = []

  getDeparment() {
    this.orderService.getDeparment().subscribe((res) => {
       this.ubigeoDeparment = res;
      });
  }

  getProvince(id_deparment) {

    id_deparment = this.orden.pickupData.addressDetails.department;
    this.orderService.getProvince(id_deparment).subscribe((res) => {
       this.ubigeoProvince = res;
    });
  }

  getDistrict(id_province) {

    if(id_province === 1){
      id_province = this.orden.pickupData.addressDetails.province = "";
      this.orderService.getDistrictDelivery(id_province).subscribe((res) => {
         this.ubigeoDistrictDelivery = res;
      });
    }

    id_province = this.orden.pickupData.addressDetails.province;
    this.orderService.getDistrict(id_province).subscribe((res) => {
       this.ubigeoDistrict = res;
    });
  }

  getDeparmentDelivey() {
    this.orderService.getDeparment().subscribe((res) => {
       this.ubigeoDeparmentDelivery = res;
      });
  }

  getProvinceDelivery(id_deparment_delivery) {
    id_deparment_delivery = this.orden.deliveryData.addressDetails.department;
    this.orderService.getProvinceDelivery(id_deparment_delivery).subscribe((res) => {
       this.ubigeoProvinceDelivery = res;
    });
  }

  getDistrictDelivery(id_province_delivery) {
    if(id_province_delivery === 1){
      id_province_delivery = this.orden.deliveryData.addressDetails.province = "";
      this.orderService.getDistrictDelivery(id_province_delivery).subscribe((res) => {
         this.ubigeoDistrictDelivery = res;
      });
    }

    id_province_delivery = this.orden.deliveryData.addressDetails.province;
    this.orderService.getDistrictDelivery(id_province_delivery).subscribe((res) => {
       this.ubigeoDistrictDelivery = res;
    });
  }

  routeType = [];
  getRouteType() {
    this.orderService.getRouteType().subscribe((res) => {
      this.routeType = res;
      console.log(this.routeType, "tipo de via")
     });
  }

  housingType = [];
  getHousingType(){
    this.orderService.getHousingType().subscribe((res) => {
      this.housingType = res;
     });
  }

  documentType = [];
  getDocumentType(){
    this.orderService.getDocumentType().subscribe((res) => {
      this.documentType = res;
     });
  }

  epicorProduct = [];
  getProduct(){
    this.orderService.getProducts().subscribe((res) => {
      this.epicorProduct = res;
     });
  }

  submitForms(){
        console.log(this.orden, "orden")
  }



  // orden

  orden: Partial<order> = {
    "customerType": undefined,
    "shipmentType": undefined,
    "epicorProduct" : undefined,
    "pickupType": 'in-office', 
    "pickupData": {
        "personDetails": {
            "fullName": undefined,
            "documentType": undefined,
            "documentId": undefined,
            "phoneNumber": undefined,
            "personId": undefined
        },
        "addressDetails": {
          "department": undefined,
          "province": undefined,
          "district": undefined,
          "urbanization": undefined,
          "housingType": undefined,
          "routeType": undefined,
          "address": undefined,
          "instructions": undefined,
          "officeArea": undefined,
          "officeId": undefined
        }
    },
    "deliveryType": 'in-office',
    "deliveryData": {
        "personDetails": {
            "fullName": undefined,
            "documentType": undefined,
            "documentId": undefined,
            "phoneNumber": undefined,
            "personId": undefined
        },
        "addressDetails": {
            "department": undefined,
            "province": undefined,
            "district": undefined,
            "urbanization": undefined,
            "housingType": undefined,
            "routeType": undefined,
            "address": undefined,
            "instructions": undefined,
            "officeArea": undefined,
            "officeId": undefined
        }
    },
    "packageType": undefined,
    "packageData": {
        "long": {
            "unit": "cm",
            "value": undefined
        },
        "width": {
            "unit": "cm",
            "value": undefined
        },
        "height": {
            "unit": "cm",
            "value": undefined
        },
        "weight": {
            "unit": "cm",
            "value": undefined
        },
        "aproxVolume": {
            "unit": "cm",
            "value": undefined
        },
        "description": undefined
    },
    "isExpress": false,
    "programmedDate": undefined
} 

}

