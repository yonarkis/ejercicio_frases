import { Component, OnInit, Input } from '@angular/core';
import { NgbModal, ModalDismissReasons, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';
import { NgbCalendar, NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { Router} from '@angular/router';

@Component({
  selector: 'app-dialogo-guardar',
  templateUrl: './dialogo-guardar.component.html',
  styleUrls: ['./dialogo-guardar.component.scss']
})
export class DialogoGuardarComponent implements OnInit {

  @Input() titulo = "Guardar / Cargar reportes"
  @Input() esPoco = false
  @Input() data = ["Reporte BCP Trimestal 2 (7/8/2019 14:34)",
  "Reporte BCP Trimestal 2 (7/8/2019 14:34)",
  "Reporte BCP Trimestal 2 (7/8/2019 14:34)",
  "Reporte BCP Trimestal 2 (7/8/2019 14:34)"]

  esGuardar = true
  clickTabs(esGuardar:boolean){
    this.esGuardar = esGuardar
  }

  
  closeResult: string;
  modalOption: NgbModalOptions = {};

  constructor(public modalService: NgbModal) { }

  ngOnInit() {
  }

  /* Popup */
  openModalSmall(contenido) {
    this.modalOption.backdrop = 'static';
    this.modalOption.keyboard = false;
    this.modalService.open(contenido, this.modalOption).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }
  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  } open(content) {
    this.modalService.open(content);
  }
}