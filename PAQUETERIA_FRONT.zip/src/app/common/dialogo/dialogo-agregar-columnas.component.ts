import { Component, OnInit, Input } from '@angular/core';
import { NgbModal, ModalDismissReasons, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';
import { NgbCalendar, NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { Router} from '@angular/router';

@Component({
  selector: 'app-dialogo-agregar-columnas',
  templateUrl: './dialogo-agregar-columnas.component.html',
  styleUrls: ['./dialogo-agregar-columnas.component.scss']
})
export class DialogoAgregarColumnasComponent implements OnInit {

  @Input() titulo = "Agregar Columnas Al Reporte"
  @Input() esPoco = false
  @Input() data = ["Coumna 1","Coumna 2","Coumna 3","Coumna 4","Coumna 5","Coumna 6","Coumna 7"]

  
  closeResult: string;
  modalOption: NgbModalOptions = {};

  constructor(public modalService: NgbModal) { }

  ngOnInit() {
  }

  /* Popup */
  openModalSmall(contenido) {
    this.modalOption.backdrop = 'static';
    this.modalOption.keyboard = false;
    this.modalService.open(contenido, this.modalOption).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }
  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  } open(content) {
    this.modalService.open(content);
  }
}