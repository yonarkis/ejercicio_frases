import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-atencion-reclamos',
  templateUrl: './atencion-reclamos.component.html',
  styleUrls: ['./atencion-reclamos.component.scss']
})
export class AtencionReclamosComponent implements OnInit {

  constructor() { }
  color = "azul"
  clickColor(c:string){
    this.color = c
  }
  historia = 6
  clickHistoria(n:number){
    this.historia = n
  }

  ngOnInit() {
  }

}
