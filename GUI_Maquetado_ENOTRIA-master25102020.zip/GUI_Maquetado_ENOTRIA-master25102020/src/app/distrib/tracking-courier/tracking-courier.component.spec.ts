import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TrackingCourierComponent } from './tracking-courier.component';

describe('TrackingCourierComponent', () => {
  let component: TrackingCourierComponent;
  let fixture: ComponentFixture<TrackingCourierComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TrackingCourierComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TrackingCourierComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
