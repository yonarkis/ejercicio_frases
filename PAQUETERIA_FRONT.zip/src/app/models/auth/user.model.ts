export class User {
  public nombre : string;
  public nombreCompleto : string;
  public apellidoMaterno : string;
    public apellidoPaterno : string;
    public estado :string;
    public idperfil : number ;
    public nombreperfil : string;
    public idusuario : string;
    public token : string;
    public user : string;
}
