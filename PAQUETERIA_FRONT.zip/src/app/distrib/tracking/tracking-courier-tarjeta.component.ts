import { Component, OnInit, Input } from '@angular/core';
import {NgbModal, ModalDismissReasons, NgbModalOptions} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-tracking-courier-tarjeta',
  templateUrl: './tracking-courier-tarjeta.component.html',
  styleUrls: ['./tracking-courier-tarjeta.component.scss']
})
export class TrackingCourierTarjetaComponent implements OnInit {

  @Input() color = "#90BD4C"
  @Input() avance = 69



  constructor(private modalService: NgbModal) { }
  /* POPUPS  */
  closeResult: string;
  modalOptionSmall: NgbModalOptions = {};
  modalOption: NgbModalOptions = {};

  openModalSmall(contenido) {
    this.modalOptionSmall.backdrop = 'static';
    this.modalOptionSmall.keyboard = false;
    this.modalService.open(contenido, this.modalOptionSmall).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  openModalLarge(contenido) {
    this.modalOption.backdrop = 'static';
    this.modalOption.keyboard = false;
    this.modalOption.windowClass = 'xlModal'
    this.modalService.open(contenido, this.modalOption).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  } open(content) {
    this.modalService.open(content);
  }
  /* FIN POPUPS  */
  ngOnInit() {
  }

}
