import { Component, OnInit } from '@angular/core';
import { NgbModal, ModalDismissReasons, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';
import { NgbCalendar, NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { Router } from '@angular/router';

@Component({
  selector: 'app-courier-detalle',
  templateUrl: './courier-detalle.component.html',
  styleUrls: ['./courier-detalle.component.scss']
})
export class CourierDetalleComponent implements OnInit {
  submenulinks = false

  // VARIABLES DIALOGOS
  titulo = "Duplicar Registro"
  cuerpo = "Se generará un duplicado del registro"
  dialogoTipo = 1


  model: NgbDateStruct;
  model2: NgbDateStruct;

  constructor(private modalService: NgbModal, private calendar: NgbCalendar, private router: Router) { }

  controlOver = true
  clickControl() {
    this.controlOver = !this.controlOver
  }

  clickControlOver(n: number) {
    var el = this.controlOver[n];
    el = !el
  }


  // Selección múltiple
  selectall = false
  selectToggle() {
    this.selectall = !this.selectall
  }
  // FILTRO
  filtroHidden = true
  filtroToggle() {
    this.filtroHidden = !this.filtroHidden
  }


  /* POPUPS  */
  closeResult: string;
  modalOptionSmall: NgbModalOptions = {};
  modalOption: NgbModalOptions = {};

  openModalSmall(contenido) {
    this.modalOptionSmall.backdrop = 'static';
    this.modalOptionSmall.keyboard = false;
    this.modalService.open(contenido, this.modalOptionSmall).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  openModalLarge(contenido) {
    this.modalOption.backdrop = 'static';
    this.modalOption.keyboard = false;
    this.modalOption.windowClass = 'xlModal'
    this.modalService.open(contenido, this.modalOption).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  } open(content) {
    this.modalService.open(content);
  }
  /* FIN POPUPS  */
  ngOnInit() {
  }

}
