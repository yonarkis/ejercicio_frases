import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DialogoEdicionTablaComponent } from './dialogo-edicion-tabla.component';

describe('DialogoEdicionTablaComponent', () => {
  let component: DialogoEdicionTablaComponent;
  let fixture: ComponentFixture<DialogoEdicionTablaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DialogoEdicionTablaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DialogoEdicionTablaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
