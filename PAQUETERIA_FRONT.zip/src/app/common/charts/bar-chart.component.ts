import { Component, OnInit, Input } from '@angular/core';
import { Chart, ChartsModule, ChartAnnotation } from 'chart.js';
import 'chartjs-plugin-annotation';

// import { ChartOptions } from 'chart.js';
// import * as ChartAnnotation from 'chartjs-plugin-annotation';

@Component({
  selector: 'app-bar-chart',
  templateUrl: './bar-chart.component.html',
  styleUrls: ['./bar-chart.component.scss']
})
export class BarChartComponent implements OnInit {

  chart: any = 1;
  titulo: string;
  leyenda:any = [];
  labels:any = [];
  colores:any = [];
  @Input() data: any;
  dataFinal = [];
  x = [];

  constructor() { }

  ngOnInit() {
    this.titulo = this.data["titulo"];
    var tienda = this.data["data"];

    for (let i = 0; i < this.data["cantidad-barras"]; i++) {
      this.leyenda.push(this.data["leyenda"]["l"+(i+1)]);
      this.colores.push(this.data["colores"]["color"+(i+1)]);

      var miarr = new Array;
      this.x.push(i);

      for (let index = 0; index < this.data["data"].length; index++) {
        this.labels[index] = this.data["data"][index]["label"];
        miarr.push(tienda[index]["cantidad"+(i+1)])

      }
      this.x[i] = miarr;
      this.dataFinal.push(
        {
          label: this.leyenda[i],
          fill: false,
          data: this.x[i],
          backgroundColor: this.colores[i],
        }
      )
    }

   
  }

  ngAfterViewInit(){

    var options = {
      responsive: true,
      maintainAspectRatio: false,
      title: {
        display: true,
        text: this.titulo
      },

      legend: {
        display: true,
        position: 'bottom',
      },
      scales: {
        xAxes: [{
          stacked: false,
          barPercentage: 1,
          gridLines: {
            display: false
          },
          ticks: {
            display: true //this will remove only the label
          }
        }],
        yAxes: [{
          id: 'B',
          ticks: {
            beginAtZero: true
          },
          gridLines: {
            display: false,
          },
        }]
      },      
      annotation: {
        annotations: [{
            type: 'line',
            mode: 'horizontal',
            scaleID: 'B',
            value: '4100',
            borderColor: 'red',
            borderWidth: 2
        }],
        drawTime: "afterDraw" // (default)
    }
    };
    
    this.chart = new Chart('bar'+this.data["id"], {
      type: 'bar',
      data: {
        labels: this.labels,
        datasets: this.dataFinal,
      },
      options: options,
    });

/*     Chart.pluginService.register({
      afterDraw: function(chart) {
  
          if (typeof chart.config.options.lineAt != 'undefined') {
              var lineAt = chart.config.options.lineAt;
              var ctxPlugin = chart.chart.ctx;
              var xAxe = chart.scales[chart.config.options.scales.xAxes[0].id];
              var yAxe = chart.scales[chart.config.options.scales.yAxes[0].id];
  
              var position = yAxe.getPixelForValue(lineAt)
  
              ctxPlugin.strokeStyle = "red";
              ctxPlugin.beginPath();
              ctxPlugin.moveTo(xAxe.left, position);
              ctxPlugin.lineTo(xAxe.right, position);
              ctxPlugin.stroke();
          }
      }
  }); */

  }

}
