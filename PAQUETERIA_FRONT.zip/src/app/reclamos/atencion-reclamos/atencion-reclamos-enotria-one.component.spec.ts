import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AtencionReclamosEnotriaOneComponent } from './atencion-reclamos-enotria-one.component';

describe('AtencionReclamosEnotriaOneComponent', () => {
  let component: AtencionReclamosEnotriaOneComponent;
  let fixture: ComponentFixture<AtencionReclamosEnotriaOneComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AtencionReclamosEnotriaOneComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AtencionReclamosEnotriaOneComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
