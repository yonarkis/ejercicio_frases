import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-atencion-reclamos-enotria-one',
  templateUrl: './atencion-reclamos-enotria-one.component.html',
  styleUrls: ['./atencion-reclamos-enotria-one.component.scss']
})
export class AtencionReclamosEnotriaOneComponent implements OnInit {

  @Input() color = "azul" // azul, rojo, ambar, verde
  constructor() { }
  selec = "reclamo" // reclamo, datos, responder
  clickSlec(t:string){
    this.selec = t
  }
  dummy(t:string){
    console.log(t)
  }


  ngOnInit() {
  }

}