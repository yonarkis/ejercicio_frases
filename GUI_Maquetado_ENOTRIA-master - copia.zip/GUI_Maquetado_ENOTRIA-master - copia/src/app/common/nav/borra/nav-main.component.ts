import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nav-main',
  templateUrl: './nav-main.component.html',
  styleUrls: ['./nav-main.component.scss']
})
export class NavMainComponent implements OnInit {

  iconSelected = 0
  navbar = false

  constructor() { }

  select(n:number){
    n==this.iconSelected ? this.iconSelected=0 : this.iconSelected=n
  }
  test(){
    // event.stopPropagation();
    console.log("CLICK")
  }
  navbarSwitch(){
    this.navbar = !this.navbar
  }

  ngOnInit() {
  }

}
