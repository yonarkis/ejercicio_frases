import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import {StorageService} from '../app/services/auth/storage.service';
//import { ApiService } from '@app/api.service';


@Injectable({
  providedIn: 'root'
})
export class AuthInterceptorService {

  constructor(
    public storaService: StorageService
  ) { }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

    return next.handle(req).pipe(
      catchError((err: HttpErrorResponse) => {
        if (err.status === 403 || err.status === 401) {
            this.storaService.logout();
        }
        return throwError( err );
      })
    );
  }
}
