import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DialogoCalendarComponent } from './dialogo-calendar.component';

describe('DialogoCalendarComponent', () => {
  let component: DialogoCalendarComponent;
  let fixture: ComponentFixture<DialogoCalendarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DialogoCalendarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DialogoCalendarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
